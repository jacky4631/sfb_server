# 美团联盟新版api接口 api-gateway-demo-sign-java
request signature demo by java
