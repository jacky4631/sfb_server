
# InstallPosWithProductPrePosParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**preShopName** | **String** |  |  [optional]
**serialNumber** | **String** |  |  [optional]



