
# InstallPosWithProductPreShopParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**createTime** | **String** |  |  [optional]
**address** | **String** |  |  [optional]
**linkman** | **String** |  |  [optional]
**phone** | **String** |  |  [optional]
**mobile** | **String** |  |  [optional]
**orderCode** | **String** |  |  [optional]
**status** | **String** |  |  [optional]
**province** | **String** |  |  [optional]
**city** | **String** |  |  [optional]
**county** | **String** |  |  [optional]
**bindphone** | **String** |  |  [optional]
**isupdate** | **Boolean** |  |  [optional]
**isNew** | **Boolean** |  |  [optional]
**_default** | **Boolean** |  |  [optional]



