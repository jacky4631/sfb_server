
# InstallPosWithProductInstallPosWithProductParamParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customerNumber** | **String** |  |  [optional]
**agentCode** | **String** |  |  [optional]
**productCode** | **String** |  |  [optional]
**externalMcc** | **String** |  |  [optional]
**customerType** | **String** |  |  [optional]
**shopList** | [**List&lt;InstallPosWithProductPreShopParam&gt;**](InstallPosWithProductPreShopParam.md) |  |  [optional]
**posList** | [**List&lt;InstallPosWithProductPrePosParam&gt;**](InstallPosWithProductPrePosParam.md) |  |  [optional]
**timeStampbind** | **Long** |  |  [optional]
**hmacbind** | **String** |  |  [optional]



