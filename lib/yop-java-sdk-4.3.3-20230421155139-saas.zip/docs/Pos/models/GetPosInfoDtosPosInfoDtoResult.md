
# GetPosInfoDtosPosInfoDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**serialNumber** | **String** | 机具序列号 |  [optional]
**posCATI** | **String** | 终端号 |  [optional]
**customerNumber** | **String** | 商户编号 |  [optional]
**shortName** | **String** | 商户简称 |  [optional]
**shopCustomerNumber** | **String** | 网点商户编号 |  [optional]
**shopName** | **String** | 网点名称 |  [optional]
**address** | **String** | 网点详细地址 |  [optional]
**fullName** | **String** | 商户全称 |  [optional]
**productLine** | **String** | 产品线 |  [optional]
**salesName** | **String** | 销售名称 |  [optional]
**posStatus** | **String** | 机具状态 |  [optional]
**posType** | **String** | 机具型号 |  [optional]
**posManufacturer** | **String** | 机具所属厂商 |  [optional]
**posCreateTime** | **String** | 绑机时间 |  [optional]



