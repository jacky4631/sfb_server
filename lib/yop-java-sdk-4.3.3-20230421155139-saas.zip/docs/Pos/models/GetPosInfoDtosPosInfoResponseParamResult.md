
# GetPosInfoDtosPosInfoResponseParamResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnMsg** | **String** | 返回信息 |  [optional]
**returnCode** | **String** | 返回码 |  [optional]
**posInfos** | [**List&lt;GetPosInfoDtosPosInfoDtoResult&gt;**](GetPosInfoDtosPosInfoDtoResult.md) | 未命名 |  [optional]



