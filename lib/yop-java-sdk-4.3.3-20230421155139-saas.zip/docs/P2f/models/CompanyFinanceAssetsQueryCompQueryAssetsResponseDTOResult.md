
# CompanyFinanceAssetsQueryCompQueryAssetsResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** | 状态 |  [optional]
**errorCode** | **String** | 错误码 |  [optional]
**errorMsg** | **String** | 错误描述 |  [optional]
**channelNo** | **String** | 渠道号 |  [optional]
**assetsAmount** | [**BigDecimal**](BigDecimal.md) | 企业号可用资产 |  [optional]
**totalProfitAmount** | [**BigDecimal**](BigDecimal.md) | 累计收益 |  [optional]
**yesterdayProfit** | [**BigDecimal**](BigDecimal.md) | 昨日收益 |  [optional]
**availableBal** | [**BigDecimal**](BigDecimal.md) | 可用余额 |  [optional]



