
# CompanyFinanceTransactionQueryCompTransactionVOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestNo** | **String** | 请求号 |  [optional]
**requestTime** | **String** | 请求时间 |  [optional]
**p2fOrderId** | **String** | P2F订单号 |  [optional]
**transactionType** | **String** | 交易类型 |  [optional]
**amount** | **String** | 交易金额 |  [optional]



