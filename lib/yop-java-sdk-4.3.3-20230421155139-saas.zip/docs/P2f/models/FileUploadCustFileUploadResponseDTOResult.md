
# FileUploadCustFileUploadResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** | 订单状态 |  [optional]
**errorCode** | **String** | 错误码 |  [optional]
**errorMsg** | **String** | 错误信息 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**fileType** | **String** | 文件类型 |  [optional]
**image** | **String** | 文件存储路径 |  [optional]
**imageOriginalFileName** | **String** | 上传文件名称 |  [optional]
**imageFileSize** | **String** | 上传文件大小 |  [optional]
**imageMd5** | **String** | 文件MD5值 |  [optional]



