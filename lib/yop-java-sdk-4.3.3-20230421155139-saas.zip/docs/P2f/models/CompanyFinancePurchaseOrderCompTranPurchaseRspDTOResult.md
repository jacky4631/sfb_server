
# CompanyFinancePurchaseOrderCompTranPurchaseRspDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** | 状态 |  [optional]
**errorCode** | **String** | 错误码 |  [optional]
**errorMsg** | **String** | 错误消息 |  [optional]
**merchantNo** | **String** | 商户号 |  [optional]
**requestNo** | **String** | 请求号 |  [optional]



