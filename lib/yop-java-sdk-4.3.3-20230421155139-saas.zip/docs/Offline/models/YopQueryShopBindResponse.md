
# YopQueryShopBindResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agentMerchantNo** | **String** | &lt;div&gt;终端代理商商编，指付款采购终端的商编&lt;/div&gt; | 
**terminalNo** | **String** | &lt;pre&gt;终端号&lt;/pre&gt; | 
**shopName** | **String** | &lt;pre&gt;网点名称&lt;/pre&gt; | 
**shopNo** | **String** | &lt;pre&gt;网点编号&lt;/pre&gt; | 
**merchantNo** | **String** | &lt;pre&gt;终端所属收单商编&lt;/pre&gt; | 
**serialNo** | **String** | &lt;p&gt;终端序列号&lt;/p&gt; | 



