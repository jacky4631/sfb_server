
# YopQueryAgentRspDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**yopQueryAgentResponses** | [**List&lt;YopQueryAgentResponse&gt;**](YopQueryAgentResponse.md) | &lt;p&gt;代理商信息&lt;/p&gt; | 
**retCode** | **String** | &lt;p&gt;返回码&lt;/p&gt; | 
**retMsg** | **String** | &lt;p&gt;返回信息&lt;/p&gt; | 



