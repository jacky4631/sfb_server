
# BindTerminalMemo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**textBox** | **Integer** | &lt;div data-page-id&#x3D;\&quot;doxcnTwjJz4RAeZptELxdVTBOTd\&quot; data-docx-has-block-data&#x3D;\&quot;false\&quot;&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcnq2keOS40MKycK62DKaX51f\&quot;&gt;输入框是否展示及必填&lt;/div&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcnqiOqOIWqCQUCAZ5droHyRf\&quot;&gt;0:不展示&lt;/div&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcnwG4GicgiOcEW8CBnDA6Ypb\&quot;&gt;1:展示，非必填&lt;/div&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcnEcQQkmMOAkgk8ofUMwjB9b\&quot;&gt;2:展示，必填&lt;/div&gt; &lt;/div&gt; |  [optional]
**textBoxPrompt** | **String** | &lt;div data-page-id&#x3D;\&quot;doxcnTwjJz4RAeZptELxdVTBOTd\&quot; data-docx-has-block-data&#x3D;\&quot;false\&quot;&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcnqMcOuawgcYokMQZNWEwH2U\&quot;&gt;输入框文案，最长15个汉字/字符&lt;/div&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcnSaq2wUaeqcyQm3w4a4mOcb\&quot;&gt;仅textBox &#x3D;&#x3D; 1或2时生效&lt;/div&gt; &lt;/div&gt; |  [optional]
**dropDownList** | **Integer** | &lt;div data-page-id&#x3D;\&quot;doxcnTwjJz4RAeZptELxdVTBOTd\&quot; data-docx-has-block-data&#x3D;\&quot;false\&quot;&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcnSUecWueOwOawY9fsVYXOdb\&quot;&gt;拉选框是否展示&lt;/div&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcngCqEWCgYYauaQ1io902V8f\&quot;&gt;0: 不展示&lt;/div&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcnUUqsCecqqq2QsNTae8ntvd\&quot;&gt;1: 展示（必选）&lt;/div&gt; &lt;/div&gt; |  [optional]
**dropDownListPrompt** | **String** | &lt;div data-page-id&#x3D;\&quot;doxcnTwjJz4RAeZptELxdVTBOTd\&quot; data-docx-has-block-data&#x3D;\&quot;false\&quot;&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcnUu8ai6yUmmCWyCOTmoQDGb\&quot;&gt;拉选框文案，最长15个汉字/字符&lt;/div&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcniagwmKu6KuAW4G4ma7Yd2b\&quot;&gt;仅dropDownList &#x3D;&#x3D; 1时生效&lt;/div&gt; &lt;/div&gt; |  [optional]
**dropDownListOption** | **String** | &lt;div data-page-id&#x3D;\&quot;doxcnTwjJz4RAeZptELxdVTBOTd\&quot; data-docx-has-block-data&#x3D;\&quot;false\&quot;&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcn4eUcGQUyS6kaAhNN1WPW3Y\&quot;&gt;拉选内容，最多10项，每项最长15个汉字/字符，以英文逗号分隔&lt;/div&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcnMgGIYuqKs0U26jLe8POZNc\&quot;&gt;仅dropDownList &#x3D;&#x3D; 1时生效&lt;/div&gt; &lt;/div&gt; |  [optional]



