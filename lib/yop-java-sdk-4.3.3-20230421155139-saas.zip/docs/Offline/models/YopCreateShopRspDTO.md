
# YopCreateShopRspDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**retCode** | **String** | &lt;p&gt;返回码&lt;/p&gt; | 
**retMsg** | **String** | &lt;p&gt;返回信息&lt;/p&gt; | 
**shopNo** | **String** | &lt;pre&gt;网点编号&lt;/pre&gt; | 



