
# PayWayInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userScan** | **Integer** | &lt;div data-page-id&#x3D;\&quot;doxcnTwjJz4RAeZptELxdVTBOTd\&quot; data-docx-has-block-data&#x3D;\&quot;false\&quot;&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcn0qMSw4qYgocMUvPJMGht5e\&quot;&gt;用户扫码入口&lt;/div&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcnIGEU86ECKYSqwTVDsLLzTf\&quot;&gt;0：隐藏&lt;/div&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcn0qsm4uCEis66ETPjeJmt3f\&quot;&gt;1：展示（默认）&lt;/div&gt; &lt;/div&gt; |  [optional]
**merchantScan** | **Integer** | &lt;div data-page-id&#x3D;\&quot;doxcnTwjJz4RAeZptELxdVTBOTd\&quot; data-docx-has-block-data&#x3D;\&quot;false\&quot;&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcne8MQAKeqImwwYZD4j7CSbh\&quot;&gt;商家扫码入口&lt;/div&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcnaOEE08eOayw2YT7xThal77\&quot;&gt;0：隐藏&lt;/div&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcnckse2AAG2YKKUFWGsKnMCg\&quot;&gt;1：展示（默认）&lt;/div&gt; &lt;/div&gt; |  [optional]
**reverse** | **Integer** | &lt;div data-page-id&#x3D;\&quot;doxcnTwjJz4RAeZptELxdVTBOTd\&quot; data-docx-has-block-data&#x3D;\&quot;false\&quot;&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcnaqSqCOOG6mqMaOKgEkfzhh\&quot;&gt;退货入口&lt;/div&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcnG60Suc68GoSM6DfUthz7db\&quot;&gt;0：隐藏&lt;/div&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcn0qUEyo0sOKyAoRqbk7pWKd\&quot;&gt;1：展示（默认）&lt;/div&gt; &lt;/div&gt; |  [optional]
**refund** | **Integer** | &lt;div data-page-id&#x3D;\&quot;doxcnTwjJz4RAeZptELxdVTBOTd\&quot; data-docx-has-block-data&#x3D;\&quot;false\&quot;&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcn2aOU0q6yGesugQ09PpAxnb\&quot;&gt;撤销入口&lt;/div&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcnE0MScoswCKGMeGHXLD8Qye\&quot;&gt;0：隐藏&lt;/div&gt; &lt;div class&#x3D;\&quot;ace-line ace-line old-record-id-doxcn48I80aKgasaiekQXHlXKvh\&quot;&gt;1：展示（默认）&lt;/div&gt; &lt;/div&gt; |  [optional]



