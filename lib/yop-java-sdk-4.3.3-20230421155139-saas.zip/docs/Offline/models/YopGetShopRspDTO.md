
# YopGetShopRspDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**retCode** | **String** | &lt;p&gt;返回码&lt;/p&gt; | 
**retMsg** | **String** | &lt;p&gt;返回信息&lt;/p&gt; | 
**shopInfos** | [**List&lt;GetShopRspDTO&gt;**](GetShopRspDTO.md) | &lt;p&gt;网点信息&lt;/p&gt; | 



