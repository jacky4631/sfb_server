
# YopQueryShopBindRspDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bindResponses** | [**List&lt;YopQueryShopBindResponse&gt;**](YopQueryShopBindResponse.md) | &lt;p&gt;绑机信息&lt;/p&gt; | 
**retCode** | **String** | &lt;p&gt;返回码&lt;/p&gt; | 
**retMsg** | **String** | &lt;p&gt;返回信息&lt;/p&gt; |  [optional]



