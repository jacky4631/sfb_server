
# BillOverviewDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**month** | **String** | &lt;p&gt;汇总月份&lt;/p&gt; &lt;p&gt;（202212）&lt;/p&gt; | 
**detailList** | [**List&lt;BillOverviewDetailDto&gt;**](BillOverviewDetailDto.md) | &lt;p&gt;详情列表&lt;/p&gt; |  [optional]



