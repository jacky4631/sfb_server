
# TradeOrderV2APIWalletPayResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**uniqueOrderNo** | **String** | 易宝唯一流水号 |  [optional]



