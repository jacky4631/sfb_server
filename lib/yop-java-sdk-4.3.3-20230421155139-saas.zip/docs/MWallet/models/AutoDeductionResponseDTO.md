
# AutoDeductionResponseDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** |  |  [optional]
**message** | **String** |  |  [optional]
**requestNo** | **String** |  |  [optional]
**status** | **String** |  |  [optional]



