
# BankAccountQueryTradeBankAccountTradeDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**trxDate** | **String** | 交易日期 |  [optional]
**trxTime** | **String** | 交易时间 |  [optional]
**loanFlag** | **String** | 借贷标志 |  [optional]
**transAmount** | **String** | 交易金额 |  [optional]
**balance** | **String** | 账户余额 |  [optional]
**otherAccNo** | **String** | 对方卡/折号 |  [optional]
**otherAccountName** | **String** | 对方账户名称 |  [optional]
**tranNo** | **String** | 交易流水号 |  [optional]
**channel** | **String** | 发起方渠道 |  [optional]
**tradeDetail** | **String** | 交易详情 |  [optional]
**memo** | **String** | 摘要 |  [optional]
**tranaccreason** | **String** | 转账原因 |  [optional]



