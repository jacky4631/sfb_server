
# RechargeInitiateRequestURLResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回消息 |  [optional]
**url** | **String** | 交易支付确认控件URL |  [optional]



