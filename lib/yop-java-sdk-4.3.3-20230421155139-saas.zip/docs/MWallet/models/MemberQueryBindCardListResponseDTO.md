
# MemberQueryBindCardListResponseDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** |  |  [optional]
**message** | **String** |  |  [optional]
**bindCardInfoList** | [**List&lt;BindCardInfo&gt;**](BindCardInfo.md) |  |  [optional]



