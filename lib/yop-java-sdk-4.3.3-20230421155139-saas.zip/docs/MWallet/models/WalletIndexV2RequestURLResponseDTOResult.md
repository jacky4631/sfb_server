
# WalletIndexV2RequestURLResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**url** | **String** | 钱包访问URL |  [optional]



