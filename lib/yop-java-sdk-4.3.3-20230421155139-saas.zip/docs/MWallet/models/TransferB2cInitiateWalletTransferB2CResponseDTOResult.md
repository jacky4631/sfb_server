
# TransferB2cInitiateWalletTransferB2CResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回消息 |  [optional]
**status** | **String** | 请求结果状态 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**orderNo** | **String** | 易宝统一订单号 |  [optional]
**orderAmount** | **String** | 转账订单金额 |  [optional]



