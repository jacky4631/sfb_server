
# BankAccountQueryComplaintQueryComplaintOrderRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息 |  [optional]
**accountNo** | **String** | 电子账号 |  [optional]
**tradeTime** | **String** | 订单交易日期 |  [optional]
**bankTradeNo** | **String** | 银行交易流水 |  [optional]
**amountGear** | **String** | 交易金额档位 |  [optional]
**tradeDetail** | **String** | 摘要 |  [optional]
**tradeType** | **String** | 交易类型 |  [optional]



