
# RechargeQueryQueryRechargeResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回消息 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**businessNo** | **String** | 易宝订单号 |  [optional]
**amount** | [**BigDecimal**](BigDecimal.md) | 充值金额 |  [optional]
**bindId** | **String** | 绑卡ID |  [optional]
**cardNo** | **String** | 卡号 |  [optional]
**bankName** | **String** | 银行名称 |  [optional]
**bankCode** | **String** | 银行编码 |  [optional]
**orderStatus** | **String** | 订单状态 |  [optional]
**orderTime** | **String** | 订单完成时间 |  [optional]
**userFee** | [**BigDecimal**](BigDecimal.md) | 用户手续费 |  [optional]



