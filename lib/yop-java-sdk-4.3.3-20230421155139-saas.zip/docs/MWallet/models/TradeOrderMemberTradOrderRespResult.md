
# TradeOrderMemberTradOrderRespResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回消息 |  [optional]
**uniqueOrderNo** | **String** | 易宝统一订单号 |  [optional]
**requestNo** | **String** | 商户请求流水号 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**parentMerchantNo** | **String** | 业务发起方商编 |  [optional]
**cashierUrl** | **String** | 收银台链接 |  [optional]



