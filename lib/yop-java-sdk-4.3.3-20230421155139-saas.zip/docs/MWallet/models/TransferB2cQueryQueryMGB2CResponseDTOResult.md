
# TransferB2cQueryQueryMGB2CResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**businessNo** | **String** | 易宝订单号 |  [optional]
**orderAmount** | [**BigDecimal**](BigDecimal.md) | 转账订单金额 |  [optional]
**orderStatus** | **String** | 转账订单状态 |  [optional]
**fromMerchantNo** | **String** | 交易主体商编 |  [optional]
**toMerchantNo** | **String** | 转帐接收方平台商编 |  [optional]
**toMemberNo** | **String** | 转出方易宝用户编号 |  [optional]



