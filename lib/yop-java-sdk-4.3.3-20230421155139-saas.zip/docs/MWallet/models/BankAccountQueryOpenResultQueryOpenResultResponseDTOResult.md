
# BankAccountQueryOpenResultQueryOpenResultResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**yeepayOrderNo** | **String** | 易宝开户申请号 |  [optional]
**applyStatus** | **String** | 开户状态 |  [optional]
**elecAccount** | **String** | 银行电子账号 |  [optional]
**bankAccountLevel** | **String** | 银行账户的等级 |  [optional]
**accountType** | **String** | 银行编码 |  [optional]
**yeepayMemberNo** | **String** | 易宝会员编号 |  [optional]



