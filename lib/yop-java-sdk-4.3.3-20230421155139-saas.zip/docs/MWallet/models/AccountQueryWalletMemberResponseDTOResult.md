
# AccountQueryWalletMemberResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回消息 |  [optional]
**walletUserNo** | **String** | 钱包账户ID |  [optional]
**walletStatus** | **String** | 钱包账户状态 |  [optional]
**balance** | **String** | 钱包账户余额 |  [optional]
**name** | **String** | 姓名 |  [optional]
**certificateType** | **String** | 证件类型 |  [optional]
**certificateNo** | **String** | 证件号码 |  [optional]
**walletCategory** | **String** | 钱包账户等级 |  [optional]
**tradePswdSet** | **Boolean** | 是否已设置交易密码 |  [optional]



