
# BankAccountQueryTradeQueryBankAccountTradeRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息 |  [optional]
**totalNum** | **String** | 总记录条数 |  [optional]
**debitSum** | **String** | 支出总笔数 |  [optional]
**debitAmt** | **String** | 支出总金额 |  [optional]
**loanSum** | **String** | 收入总笔数 |  [optional]
**loanAmt** | **String** | 收入总金额 |  [optional]
**queryToken** | **String** | 查询token |  [optional]
**queryTime** | **String** | 查询时间戳 |  [optional]
**detailList** | [**List&lt;BankAccountQueryTradeBankAccountTradeDTOResult&gt;**](BankAccountQueryTradeBankAccountTradeDTOResult.md) | 交易详情 |  [optional]



