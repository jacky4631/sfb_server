
# MemberQueryQueryMemberInfoResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**memberNo** | **String** | 会员号 |  [optional]
**externalUserId** | **String** | 商户用户ID |  [optional]
**walletStatus** | **String** | 钱包账户状态 |  [optional]
**walletCategory** | **String** | 钱包账户等级 |  [optional]
**renewStatus** | **String** | 续费状态 |  [optional]



