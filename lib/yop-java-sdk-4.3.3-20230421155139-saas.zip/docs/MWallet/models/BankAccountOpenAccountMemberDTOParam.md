
# BankAccountOpenAccountMemberDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memberName** | **String** |  |  [optional]
**idCardNo** | **String** |  |  [optional]
**idCardType** | **String** |  |  [optional]
**mobile** | **String** |  |  [optional]
**sex** | **String** |  |  [optional]
**address** | **String** |  |  [optional]
**idCardBeginDate** | **String** |  |  [optional]
**idCardEndDate** | **String** |  |  [optional]
**idCardOrg** | **String** |  |  [optional]
**corpOrationType** | **String** |  |  [optional]
**idImageFront** | **String** |  |  [optional]
**idImageBack** | **String** |  |  [optional]
**faceImage** | **String** |  |  [optional]
**bankNo** | **String** |  |  [optional]



