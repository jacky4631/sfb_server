
# BankAccountOpenBankAccountRequestDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parentMerchantNo** | **String** |  |  [optional]
**merchantNo** | **String** |  |  [optional]
**initiateMerchantNo** | **String** |  |  [optional]
**requestNo** | **String** |  |  [optional]
**businessCode** | **String** |  |  [optional]
**merchantMemberNo** | **String** |  |  [optional]
**accountType** | **String** |  |  [optional]
**bankAccountLevel** | **String** |  |  [optional]
**marketProductCode** | **String** |  |  [optional]
**memberInfo** | [**BankAccountOpenAccountMemberDTOParam**](BankAccountOpenAccountMemberDTOParam.md) |  |  [optional]



