
# FreeSecretQueryResponseDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** |  |  [optional]
**agreementStatus** | **String** |  |  [optional]
**message** | **String** |  |  [optional]



