
# CardQueryRequestURLResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回消息 |  [optional]
**url** | **String** | 查询绑定银行卡URL |  [optional]



