
# AgreementPaymentCancelFreeSecretCancelResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**status** | **String** | 解约结果 |  [optional]



