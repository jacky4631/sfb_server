
# AutoWithdrawResponseDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**businessNo** | **String** |  |  [optional]
**code** | **String** |  |  [optional]
**orderStatus** | **String** |  |  [optional]
**message** | **String** |  |  [optional]



