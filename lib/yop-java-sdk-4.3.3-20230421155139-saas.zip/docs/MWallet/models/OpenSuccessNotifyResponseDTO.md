
# OpenSuccessNotifyResponseDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | &lt;p&gt;返回码&lt;/p&gt; |  [optional]
**message** | **String** | &lt;p&gt;返回信息&lt;/p&gt; |  [optional]



