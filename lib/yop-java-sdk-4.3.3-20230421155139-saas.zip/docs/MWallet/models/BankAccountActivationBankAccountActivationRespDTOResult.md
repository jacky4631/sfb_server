
# BankAccountActivationBankAccountActivationRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息 |  [optional]
**status** | **String** | 状态 |  [optional]
**requestNo** | **String** | 请求号 |  [optional]



