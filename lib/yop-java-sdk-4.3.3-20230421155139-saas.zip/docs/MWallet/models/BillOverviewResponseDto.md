
# BillOverviewResponseDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** |  |  [optional]
**message** | **String** |  |  [optional]
**overviewList** | [**List&lt;BillOverviewDto&gt;**](BillOverviewDto.md) | &lt;p&gt;总览列表&lt;/p&gt; |  [optional]



