
# BindCardInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bankCode** | **String** |  |  [optional]
**disable** | **Boolean** |  |  [optional]
**cardId** | **String** |  |  [optional]
**cardType** | **String** |  |  [optional]
**bankName** | **String** |  |  [optional]
**cardNo** | **String** |  |  [optional]
**bindId** | **Long** |  |  [optional]



