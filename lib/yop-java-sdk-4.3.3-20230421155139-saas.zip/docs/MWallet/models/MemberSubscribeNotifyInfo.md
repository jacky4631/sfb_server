
# MemberSubscribeNotifyInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**merchantUserNo** | **String** | &lt;p&gt;会员外部用户标识&lt;/p&gt; |  [optional]
**walletUserNo** | **String** | &lt;pre&gt;易宝会员编号&lt;/pre&gt; |  [optional]



