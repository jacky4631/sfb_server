
# BankAccountQueryWithdrawQueryBankAccountWithDrawRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息 |  [optional]
**status** | **String** | 订单状态 |  [optional]
**finishTime** | **String** | 完成时间 |  [optional]
**createTime** | **String** | 创建时间 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**withdrawPrice** | [**BigDecimal**](BigDecimal.md) | 提现金额 |  [optional]
**accountNo** | **String** | 电子账号 |  [optional]
**accountType** | **String** | 账户类型 |  [optional]
**oneAccountBankNo** | **String** | 绑定的一类卡号 |  [optional]
**bindBankPhone** | **String** | 绑定的手机号 |  [optional]
**remark** | **String** | 提现备注 |  [optional]



