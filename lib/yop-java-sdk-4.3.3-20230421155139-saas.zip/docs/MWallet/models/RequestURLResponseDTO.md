
# RequestURLResponseDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息&lt;br&gt;返回码的详细说明 |  [optional]
**url** | **String** | 验密签约确认控件URL |  [optional]



