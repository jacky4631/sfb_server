
# BankAccountConfirmConfirmBankAccountResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**yeepayOrderNo** | **String** | 易宝开户申请号 |  [optional]
**applyStatus** | **String** | 开户状态 |  [optional]
**elecAccount** | **String** | 银行电子账号 |  [optional]
**yeepayMemberNo** | **String** | 易宝会员号 |  [optional]
**retryConfirm** | **String** | 是否可以重试 |  [optional]



