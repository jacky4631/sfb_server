
# AutoDeductionQueryResponseDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** |  |  [optional]
**message** | **String** |  |  [optional]
**requestNo** | **String** |  |  [optional]
**uniqueOrderNo** | **String** |  |  [optional]
**status** | **String** |  |  [optional]



