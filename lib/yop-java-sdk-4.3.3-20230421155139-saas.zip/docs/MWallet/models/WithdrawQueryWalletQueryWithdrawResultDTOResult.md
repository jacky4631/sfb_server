
# WithdrawQueryWalletQueryWithdrawResultDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**businessNo** | **String** | 易宝订单号 |  [optional]
**amount** | [**BigDecimal**](BigDecimal.md) | 提现金额 |  [optional]
**bindId** | **String** | 绑卡ID |  [optional]
**cardNo** | **String** | 卡号 |  [optional]
**bankName** | **String** | 银行名称 |  [optional]
**bankCode** | **String** | 银行编码 |  [optional]
**tradeStatus** | **String** | 状态 |  [optional]
**acceptTime** | **String** | 受理时间 |  [optional]
**completeTime** | **String** | 完成时间 |  [optional]
**userFee** | [**BigDecimal**](BigDecimal.md) | 用户手续费 |  [optional]
**withdrawType** | **String** | 提现方式 |  [optional]
**deductionAmount** | [**BigDecimal**](BigDecimal.md) | 实际扣款金额 |  [optional]
**arrivalAmount** | [**BigDecimal**](BigDecimal.md) | 到账金额 |  [optional]
**feeInnerType** | **String** | 手续费扣除方式 |  [optional]



