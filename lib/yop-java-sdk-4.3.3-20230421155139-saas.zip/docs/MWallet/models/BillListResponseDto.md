
# BillListResponseDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** |  |  [optional]
**billList** | [**List&lt;BillListDetailDto&gt;**](BillListDetailDto.md) |  |  [optional]
**message** | **String** |  |  [optional]



