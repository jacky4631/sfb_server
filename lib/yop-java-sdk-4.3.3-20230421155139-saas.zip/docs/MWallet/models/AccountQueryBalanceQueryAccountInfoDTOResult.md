
# AccountQueryBalanceQueryAccountInfoDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**elecAccount** | **String** | 账户账号 |  [optional]
**accountStatus** | **String** | 账户状态 |  [optional]
**balance** | [**BigDecimal**](BigDecimal.md) | 账户余额 |  [optional]
**bankAccountNo** | **String** | 银行绑定的一类卡号 |  [optional]
**bankAccountLevel** | **String** | 账户等级（一类户，二类户，三类户) |  [optional]
**mobile** | **String** | 手机号 |  [optional]
**accountType** | **String** | 账户类型 |  [optional]



