
# AccountQueryBalanceQueryBalanceResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息 |  [optional]
**queryAccountInfoDTOList** | [**List&lt;AccountQueryBalanceQueryAccountInfoDTOResult&gt;**](AccountQueryBalanceQueryAccountInfoDTOResult.md) | 账户信息集合 |  [optional]



