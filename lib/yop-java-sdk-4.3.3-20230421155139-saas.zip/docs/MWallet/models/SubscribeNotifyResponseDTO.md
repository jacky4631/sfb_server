
# SubscribeNotifyResponseDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** |  |  [optional]
**message** | **String** |  |  [optional]



