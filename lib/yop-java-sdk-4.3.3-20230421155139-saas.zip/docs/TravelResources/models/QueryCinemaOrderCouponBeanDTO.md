
# QueryCinemaOrderCouponBeanDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**couponCodeId** | **String** | &lt;pre&gt;券码id&lt;/pre&gt; |  [optional]
**couponCodeImageUrl** | **String** | &lt;pre&gt;券码url&lt;/pre&gt; |  [optional]
**adjusted** | **Boolean** | &lt;pre&gt;是否已调座&lt;/pre&gt; |  [optional]



