
# QueryOrderRequestDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parentMerchantNo** | **String** | &lt;p&gt;请求商编&lt;/p&gt; | 
**merchantNo** | **String** | &lt;p&gt;业务商编&lt;/p&gt; | 
**merchantRequestNo** | **String** | &lt;p&gt;商户订单号&lt;/p&gt; | 
**parentMerchantRequestNo** | **String** | &lt;pre&gt;请求方订单号&lt;/pre&gt; |  [optional]



