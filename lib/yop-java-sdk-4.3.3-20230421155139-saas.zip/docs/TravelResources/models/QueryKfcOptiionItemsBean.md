
# QueryKfcOptiionItemsBean

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productName** | **String** | &lt;pre&gt;商品名称&lt;/pre&gt; |  [optional]
**quantity** | [**BigDecimal**](BigDecimal.md) | &lt;pre&gt;数量&lt;/pre&gt; |  [optional]
**imageUrl** | **String** | &lt;pre&gt;图片地址&lt;/pre&gt; |  [optional]



