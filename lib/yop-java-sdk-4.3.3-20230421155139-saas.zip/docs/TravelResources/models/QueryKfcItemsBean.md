
# QueryKfcItemsBean

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productId** | **String** | &lt;pre&gt;商品id&lt;/pre&gt; |  [optional]
**productName** | **String** | &lt;pre&gt;商品名称&lt;/pre&gt; |  [optional]
**quantity** | [**BigDecimal**](BigDecimal.md) | &lt;pre&gt;数量&lt;/pre&gt; |  [optional]
**price** | [**BigDecimal**](BigDecimal.md) | &lt;pre&gt;价格&lt;/pre&gt; |  [optional]
**imageUrl** | **String** | &lt;pre&gt;图片地址&lt;/pre&gt; |  [optional]
**canceled** | **Boolean** | &lt;pre&gt;是否已取消&lt;/pre&gt; |  [optional]
**optionItems** | [**List&lt;QueryKfcOptiionItemsBean&gt;**](QueryKfcOptiionItemsBean.md) | &lt;pre&gt;明细&lt;/pre&gt; |  [optional]



