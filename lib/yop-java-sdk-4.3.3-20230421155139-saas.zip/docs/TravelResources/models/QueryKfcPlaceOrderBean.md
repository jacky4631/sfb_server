
# QueryKfcPlaceOrderBean

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cityName** | **String** | &lt;pre&gt;城市名称&lt;/pre&gt; |  [optional]
**eatType** | **Integer** | &lt;pre&gt;1:堂食 2:外带&lt;/pre&gt; |  [optional]
**storeAddress** | **String** | &lt;pre&gt;餐厅地址&lt;/pre&gt; |  [optional]
**storeName** | **String** | &lt;pre&gt;餐厅名称&lt;/pre&gt; |  [optional]
**items** | [**List&lt;QueryKfcItemsBean&gt;**](QueryKfcItemsBean.md) | &lt;pre&gt;餐品明细&lt;/pre&gt; |  [optional]
**storeCode** | **String** | &lt;pre&gt;门店编号&lt;/pre&gt; |  [optional]



