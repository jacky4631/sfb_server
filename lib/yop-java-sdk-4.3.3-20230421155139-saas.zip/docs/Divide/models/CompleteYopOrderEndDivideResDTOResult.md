
# CompleteYopOrderEndDivideResDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**divideStatus** | **String** | 分账状态 |  [optional]
**amount** | [**BigDecimal**](BigDecimal.md) | 分账金额 |  [optional]



