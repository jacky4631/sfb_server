
# BackQueryYopQueryDivideBackResDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息描述 |  [optional]
**bizSystemNo** | **String** | 业务方标识 |  [optional]
**parentMerchantNo** | **String** | 发起方商编 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**orderId** | **String** | 商户收款请求号 |  [optional]
**uniqueOrderNo** | **String** | 易宝收款订单号 |  [optional]
**divideRequestId** | **String** | 商户分账请求号 |  [optional]
**divideBackRequestId** | **String** | 商户分账资金归还请求号 |  [optional]
**uniqueDivideBackNo** | **String** | 易宝分账资金归还订单号 |  [optional]
**divideBackDetail** | **String** | 分账资金归还详情 |  [optional]
**status** | **String** | 分账资金归还状态 |  [optional]



