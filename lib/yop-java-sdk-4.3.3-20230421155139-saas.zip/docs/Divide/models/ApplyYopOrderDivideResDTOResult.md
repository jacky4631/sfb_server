
# ApplyYopOrderDivideResDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**orderId** | **String** | 商户收款请求号 |  [optional]
**uniqueOrderNo** | **String** | 易宝收款订单号 |  [optional]
**divideRequestId** | **String** | 商户分账请求号 |  [optional]
**status** | **String** | 分账状态 |  [optional]
**divideDetail** | **String** | 分账详情 |  [optional]



