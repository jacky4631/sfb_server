
# RealnameAuthCommonInsurResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 未命名 |  [optional]
**msg** | **String** | 未命名 |  [optional]
**status** | **String** | 状态 |  [optional]
**customerNo** | **String** | 客户编号 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**queryNo** | **String** | 查询编号 |  [optional]
**terminalNo** | **String** | 终端号 |  [optional]
**tradeNo** | **String** | 交易流水号 |  [optional]
**amount** | **String** | 金额 |  [optional]
**validateSequenceNo** | **String** | 认证序列号 |  [optional]
**pealNamePaymentFlag** | **String** | 实名缴费标识 |  [optional]
**requestType** | **String** | 请求类型 |  [optional]
**requestCode** | **String** | 请求编码 |  [optional]
**transDate** | **String** | 业务交易完成时间 |  [optional]
**customerDataDTOS** | [**List&lt;RealnameAuthCustomerDataDTOResult&gt;**](RealnameAuthCustomerDataDTOResult.md) | 客户信息集合 |  [optional]



