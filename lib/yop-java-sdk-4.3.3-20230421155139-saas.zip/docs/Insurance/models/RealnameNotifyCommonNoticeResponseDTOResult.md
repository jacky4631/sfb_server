
# RealnameNotifyCommonNoticeResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 未命名 |  [optional]
**msg** | **String** | 未命名 |  [optional]
**status** | **String** | 返回状态 |  [optional]
**queryNo** | **String** | 查询请求号 |  [optional]
**amount** | **String** | 金额 |  [optional]
**tradeNo** | **String** | 交易流水号 |  [optional]



