
# RealnameAuthCustomerDataDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customerNo** | **String** | 客户编号 |  [optional]
**name** | **String** | 姓名 |  [optional]
**critType** | **String** | 证件类型 |  [optional]
**critCode** | **String** | 证件号码 |  [optional]
**mobile** | **String** | 联系电话 |  [optional]



