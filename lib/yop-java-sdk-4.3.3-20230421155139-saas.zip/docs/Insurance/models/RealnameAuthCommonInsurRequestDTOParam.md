
# RealnameAuthCommonInsurRequestDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**appkey** | **String** |  |  [optional]
**requestNo** | **String** |  |  [optional]
**customerNo** | **String** |  |  [optional]
**requestType** | **String** |  |  [optional]
**cardNo** | **String** |  |  [optional]
**payerIdCard** | **String** |  |  [optional]
**payerName** | **String** |  |  [optional]
**paymentNo** | **String** |  |  [optional]
**queryNo** | **String** |  |  [optional]
**taskNumbers** | **String** |  |  [optional]
**totalAmount** | **String** |  |  [optional]
**tradeNo** | **String** |  |  [optional]
**date** | **String** |  |  [optional]
**validateSequenceNo** | **String** |  |  [optional]
**tradingBackDataDTOS** | [**List&lt;RealnameAuthTradingBackDataDTOParam&gt;**](RealnameAuthTradingBackDataDTOParam.md) |  |  [optional]



