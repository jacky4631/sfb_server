
# RealnameAuthTradingBackDataDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customerNo** | **String** |  |  [optional]
**validateResult** | **String** |  |  [optional]
**messageCode** | **String** |  |  [optional]
**message** | **String** |  |  [optional]



