
# WechatConfigAddAppIdConfigDetailResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**appId** | **String** |  |  [optional]
**appSecret** | **String** |  |  [optional]
**appIdType** | **String** |  |  [optional]
**subscribeAppId** | **String** |  |  [optional]
**status** | **String** | 配置状态 |  [optional]
**failReason** | **String** | 失败原因 |  [optional]



