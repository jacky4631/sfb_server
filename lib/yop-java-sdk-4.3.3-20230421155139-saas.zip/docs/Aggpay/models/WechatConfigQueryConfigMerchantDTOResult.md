
# WechatConfigQueryConfigMerchantDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reportMerchantNo** | **String** | 报备商户号 |  [optional]
**tradeAuthDirList** | [**List&lt;WechatConfigQueryTradeAuthDirDTOResult&gt;**](WechatConfigQueryTradeAuthDirDTOResult.md) | 支付授权目录列表 |  [optional]
**appIdList** | [**List&lt;WechatConfigQueryAppIdConfigDetailResult&gt;**](WechatConfigQueryAppIdConfigDetailResult.md) | 支付appId配置列表 |  [optional]



