
# PayPassiveOrderResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**orderId** | **String** | 商户收款请求号 |  [optional]
**uniqueOrderNo** | **String** | 易宝收款订单号 |  [optional]
**bankOrderId** | **String** | 渠道侧商户请求号 |  [optional]
**status** | **String** | 状态 |  [optional]
**terminalPayType** | **String** | 终端授权方式 |  [optional]
**paySuccessTime** | **String** | 支付完成时间 |  [optional]
**userId** | **String** | 用户ID |  [optional]
**bankId** | **String** | 付款银行 |  [optional]



