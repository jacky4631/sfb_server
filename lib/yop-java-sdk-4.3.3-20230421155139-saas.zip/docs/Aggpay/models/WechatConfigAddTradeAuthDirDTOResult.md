
# WechatConfigAddTradeAuthDirDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tradeAuthDir** | **String** | 支付授权目录 |  [optional]
**status** | **String** | 配置状态 |  [optional]
**failReason** | **String** | 失败原因 |  [optional]



