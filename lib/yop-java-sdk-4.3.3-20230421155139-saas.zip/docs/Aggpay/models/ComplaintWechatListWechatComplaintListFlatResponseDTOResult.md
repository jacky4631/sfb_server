
# ComplaintWechatListWechatComplaintListFlatResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**list** | **String** | 投诉订单列表 |  [optional]
**count** | **Integer** | 查询总数 |  [optional]



