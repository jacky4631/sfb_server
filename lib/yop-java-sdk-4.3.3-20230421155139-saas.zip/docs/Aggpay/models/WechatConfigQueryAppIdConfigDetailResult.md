
# WechatConfigQueryAppIdConfigDetailResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**appId** | **String** | 支付appId |  [optional]
**appSecret** | **String** | 支付appSecret |  [optional]
**appIdType** | **String** | appId类型 |  [optional]
**subscribeAppId** | **String** | 关注appId |  [optional]
**status** | **String** | 配置状态 |  [optional]
**failReason** | **String** | 失败原因 |  [optional]



