
# WechatConfigAddWechatConfigRequestDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**appKey** | **String** |  |  [optional]
**parentMerchantNo** | **String** |  |  [optional]
**merchantNo** | **String** |  |  [optional]
**tradeAuthDirList** | **List&lt;String&gt;** |  |  [optional]
**appIdList** | [**List&lt;WechatConfigAddAppIdConfigDetailResult&gt;**](WechatConfigAddAppIdConfigDetailResult.md) |  |  [optional]



