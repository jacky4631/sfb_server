
# ViolationWechatChannelWechatViolationRecordDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**companyName** | **String** | 公司名称 |  [optional]
**handleMethod** | **String** | 处理方式 |  [optional]
**handleState** | **String** | 处理状态 |  [optional]
**illegalType** | **String** | 违规类型 |  [optional]
**punishTime** | **String** | 处罚时间 |  [optional]
**deadline** | **String** | 最后处理时间 |  [optional]
**reportMerchantNo** | **String** | 违规子商户号-报备商户号 |  [optional]



