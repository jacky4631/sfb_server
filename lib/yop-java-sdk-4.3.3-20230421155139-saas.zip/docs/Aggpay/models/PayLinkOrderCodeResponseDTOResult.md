
# PayLinkOrderCodeResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 接口返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**parentMerchantNo** | **String** | 发起方商编 |  [optional]
**merchantNo** | **String** | 商户收款商编 |  [optional]
**orderId** | **String** | 商户订单号 |  [optional]
**qrCodeUrl** | **String** | 订单二维码地址 |  [optional]
**uniqueOrderNo** | **String** | 易宝收款订单号 |  [optional]



