
# ComplaintWechatNegotiationHistoryWechatComplaintNegotiationHistoryFlatResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**list** | **String** | 协商历史列表 |  [optional]



