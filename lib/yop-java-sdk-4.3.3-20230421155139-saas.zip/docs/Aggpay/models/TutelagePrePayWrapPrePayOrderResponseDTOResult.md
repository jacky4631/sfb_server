
# TutelagePrePayWrapPrePayOrderResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**orderId** | **String** | 商户收款请求号 |  [optional]
**uniqueOrderNo** | **String** | 易宝收款订单号 |  [optional]
**bankOrderId** | **String** | 渠道侧商户请求号 |  [optional]
**prePayTn** | **String** | 预支付标识信息 |  [optional]
**appId** | **String** | 小程序appId |  [optional]
**miniProgramPath** | **String** | 跳转小程序的路径 |  [optional]
**miniProgramOrgId** | **String** | 小程序原始id |  [optional]



