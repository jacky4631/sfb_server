
# QueryUseridPassiveGetUserIdResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**appId** | **String** | 微信公众号ID |  [optional]
**userId** | **String** | 用户ID |  [optional]



