
# WechatConfigQueryWechatConfigResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息描述 |  [optional]
**status** | **String** | 受理状态 |  [optional]
**configResult** | [**List&lt;WechatConfigQueryConfigMerchantDTOResult&gt;**](WechatConfigQueryConfigMerchantDTOResult.md) | 配置结果 |  [optional]



