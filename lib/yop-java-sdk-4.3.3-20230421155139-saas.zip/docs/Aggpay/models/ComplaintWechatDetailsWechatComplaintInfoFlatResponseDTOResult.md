
# ComplaintWechatDetailsWechatComplaintInfoFlatResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回消息 |  [optional]
**complaintNo** | **String** | 投诉单号 |  [optional]
**complaintTime** | **String** | 投诉时间 |  [optional]
**complaintDetail** | **String** | 投诉详情 |  [optional]
**complaintState** | **String** | 投诉单状态 |  [optional]
**complaintOpenId** | **String** | 投诉人openid |  [optional]
**complaintContact** | **String** | 投诉人联系方式 |  [optional]
**complaintCount** | **Integer** | 用户投诉次数 |  [optional]
**wechatMerchantNo** | **String** | 微信商户号 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**isResponse** | **Boolean** | 是否有待回复留言 |  [optional]
**wechatOrderNo** | **String** | 微信订单号 |  [optional]
**merchantOrderNo** | **String** | 易宝商户订单号 |  [optional]
**amount** | **String** | 订单金额 |  [optional]
**bankOrderNo** | **String** | 银行订单号 |  [optional]



