
# RechargeBankPayRequestDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bankCode** | **String** |  |  [optional]
**bankPayCertificate** | **String** |  |  [optional]
**userRequestIP** | **String** |  |  [optional]
**bankUsage** | **String** |  |  [optional]
**bankAccountNo** | **String** |  |  [optional]



