
# RechargeAccountBookQueryRechargePageQueryResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回描述 |  [optional]
**totalCount** | **Long** | 总笔数 |  [optional]
**list** | [**List&lt;RechargeAccountBookQueryRechargeOrderApiDtoResult&gt;**](RechargeAccountBookQueryRechargeOrderApiDtoResult.md) | 列表 |  [optional]



