
# BankPaymentOrderBankAccountPaymentRequestDtoParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**businessMarket** | **String** |  |  [optional]
**yopMerchantNo** | **String** |  |  [optional]
**marketingProductCode** | **String** |  |  [optional]
**requestIp** | **String** |  |  [optional]
**appKey** | **String** |  |  [optional]
**parentMerchantNo** | **String** |  |  [optional]
**merchantNo** | **String** |  |  [optional]
**orderInfo** | [**BankPaymentOrderOrderInfoDtoParam**](BankPaymentOrderOrderInfoDtoParam.md) |  |  [optional]
**payerInfo** | [**BankPaymentOrderBankAccountPaymentPayerInfoDtoParam**](BankPaymentOrderBankAccountPaymentPayerInfoDtoParam.md) |  |  [optional]
**batchNos** | **List&lt;String&gt;** |  |  [optional]
**tradeScene** | **String** |  |  [optional]



