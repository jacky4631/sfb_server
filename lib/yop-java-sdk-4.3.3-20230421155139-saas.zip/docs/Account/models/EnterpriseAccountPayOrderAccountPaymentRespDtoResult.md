
# EnterpriseAccountPayOrderAccountPaymentRespDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 响应编码 |  [optional]
**message** | **String** | 响应描述信息 |  [optional]
**uniqueOrderNo** | **String** | 唯一订单号 |  [optional]
**orderId** | **String** | 请求订单号 |  [optional]
**orderStatus** | **String** | 订单状态 |  [optional]



