
# SupplierQueryQuerySupplierRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 响应码 |  [optional]
**returnMsg** | **String** | 响应描述 |  [optional]
**supplierList** | [**List&lt;SupplierQuerySupplierDTOResult&gt;**](SupplierQuerySupplierDTOResult.md) | 供应商列表 |  [optional]



