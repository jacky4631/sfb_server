
# SupplierApplyApplySupplierRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 响应码 |  [optional]
**returnMsg** | **String** | 响应描述 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**applicationStatus** | **String** | 申请状态 |  [optional]



