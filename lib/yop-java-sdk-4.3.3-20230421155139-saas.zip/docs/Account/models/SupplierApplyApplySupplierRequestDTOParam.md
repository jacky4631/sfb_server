
# SupplierApplyApplySupplierRequestDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestNo** | **String** |  |  [optional]
**initiateMerchantNo** | **String** |  |  [optional]
**merchantNo** | **String** |  |  [optional]
**supplierAccountInfo** | [**SupplierApplySupplierAccountInfoParam**](SupplierApplySupplierAccountInfoParam.md) |  |  [optional]
**supplierQualInfo** | [**SupplierApplySupplierQualInfoParam**](SupplierApplySupplierQualInfoParam.md) |  |  [optional]
**notifyUrl** | **String** |  |  [optional]
**appKey** | **String** |  |  [optional]
**reasonType** | **String** |  |  [optional]
**reason** | **String** |  |  [optional]



