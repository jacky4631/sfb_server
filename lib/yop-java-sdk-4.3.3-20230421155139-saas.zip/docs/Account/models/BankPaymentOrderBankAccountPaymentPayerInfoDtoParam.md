
# BankPaymentOrderBankAccountPaymentPayerInfoDtoParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bankCode** | **String** |  |  [optional]
**payerMerchantNo** | **String** |  |  [optional]
**payerBankAccountNo** | **String** |  |  [optional]
**payerBankAccountName** | **String** |  |  [optional]



