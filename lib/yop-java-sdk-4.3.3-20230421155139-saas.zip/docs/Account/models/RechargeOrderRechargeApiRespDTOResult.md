
# RechargeOrderRechargeApiRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回消息 |  [optional]
**orderNo** | **String** | 充值订单号 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**merchantNo** | **String** | 充值商户编号 |  [optional]
**status** | **String** | 订单状态 |  [optional]
**orderAmount** | [**BigDecimal**](BigDecimal.md) | 支付金额 |  [optional]
**remitComment** | **String** | 汇款备注码 |  [optional]



