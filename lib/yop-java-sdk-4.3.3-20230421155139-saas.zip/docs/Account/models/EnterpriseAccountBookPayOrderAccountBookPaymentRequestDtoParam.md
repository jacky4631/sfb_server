
# EnterpriseAccountBookPayOrderAccountBookPaymentRequestDtoParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**businessMarket** | **String** |  |  [optional]
**appKey** | **String** |  |  [optional]
**yopMerchantNo** | **String** |  |  [optional]
**parentMerchantNo** | **String** |  |  [optional]
**merchantNo** | **String** |  |  [optional]
**ypAccountBookNo** | **String** |  |  [optional]
**marketingProductCode** | **String** |  |  [optional]
**orderInfo** | [**EnterpriseAccountBookPayOrderOrderInfoDtoParam**](EnterpriseAccountBookPayOrderOrderInfoDtoParam.md) |  |  [optional]
**merchantRequestIp** | **String** |  |  [optional]



