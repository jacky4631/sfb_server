
# AccountManageBankAccountOpenXibOpenAccountDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mobileNo** | **String** |  |  [optional]
**bindCardNo** | **String** |  |  [optional]
**bindBankCode** | **String** |  |  [optional]
**bindCardType** | **String** |  |  [optional]
**returnUrl** | **String** |  |  [optional]
**businessLicenceEffectiveDate** | **String** |  |  [optional]
**businessLicenceExpirationDate** | **String** |  |  [optional]
**enterpriseEmail** | **String** |  |  [optional]
**registerAddress** | **String** |  |  [optional]
**legalGender** | **String** |  |  [optional]
**legalLicenceEffectiveDate** | **String** |  |  [optional]
**legalLicenceExpirationDate** | **String** |  |  [optional]
**shareholderName** | **String** |  |  [optional]
**benefitName** | **String** |  |  [optional]
**benefitCertificateType** | **String** |  |  [optional]
**benefitCertificateNo** | **String** |  |  [optional]
**benefitEffectiveDate** | **String** |  |  [optional]
**benefitExpirationDate** | **String** |  |  [optional]
**benefitAddress** | **String** |  |  [optional]



