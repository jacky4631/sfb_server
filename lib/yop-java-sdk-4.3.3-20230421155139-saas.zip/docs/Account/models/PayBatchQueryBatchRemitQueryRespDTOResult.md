
# PayBatchQueryBatchRemitQueryRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回描述 |  [optional]
**batchNo** | **String** | 批次号 |  [optional]
**batchStatus** | **String** | 批次状态 |  [optional]
**remitOrderQueryDTOList** | [**List&lt;PayBatchQueryRemitOrderQueryDTOResult&gt;**](PayBatchQueryRemitOrderQueryDTOResult.md) | 批次明细 |  [optional]



