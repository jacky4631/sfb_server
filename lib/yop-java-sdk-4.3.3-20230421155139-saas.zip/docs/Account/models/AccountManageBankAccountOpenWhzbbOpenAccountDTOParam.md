
# AccountManageBankAccountOpenWhzbbOpenAccountDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bindCardType** | **String** |  |  [optional]
**bindCardNo** | **String** |  |  [optional]
**bindBankCode** | **String** |  |  [optional]
**bindAccountName** | **String** |  |  [optional]
**businessLicenceEffectiveDate** | **String** |  |  [optional]
**businessLicenceExpirationDate** | **String** |  |  [optional]
**legalLicenceEffectiveDate** | **String** |  |  [optional]
**legalLicenceExpirationDate** | **String** |  |  [optional]
**legalMobile** | **String** |  |  [optional]
**bcpNo** | **String** |  |  [optional]
**registerAddress** | **String** |  |  [optional]
**organizationNo** | **String** |  |  [optional]
**organizationStart** | **String** |  |  [optional]
**organizationEnd** | **String** |  |  [optional]
**organizationPicUrl** | **String** |  |  [optional]
**taxNo** | **String** |  |  [optional]
**taxPicUrl** | **String** |  |  [optional]



