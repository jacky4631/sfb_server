
# AccountManageBankAccountQueryStandardOpenAccountQueryResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回状态码 |  [optional]
**returnMsg** | **String** | 返回描述信息 |  [optional]
**merchantNo** | **String** | 商编号 |  [optional]
**requestNo** | **String** | 商户订单号 |  [optional]
**orderNo** | **String** | 易宝唯一订单号 |  [optional]
**status** | **String** | 开户状态 |  [optional]
**bankAccountNo** | **String** | 银行账户号 |  [optional]
**bankCustomerNo** | **String** | 银行客户号 |  [optional]
**openRequestTime** | **String** | 开户请求时间 |  [optional]
**openCompleteTime** | **String** | 开户完成时间 |  [optional]
**failReason** | **String** | 失败原因 |  [optional]



