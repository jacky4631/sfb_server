
# PayBatchOrderBatchRemitReqDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**appKey** | **String** |  |  [optional]
**saleProductCode** | **String** |  |  [optional]
**initiateMerchantNo** | **String** |  |  [optional]
**merchantNo** | **String** |  |  [optional]
**parentMerchantNo** | **String** |  |  [optional]
**batchNo** | **String** |  |  [optional]
**receiveType** | **String** |  |  [optional]
**detailList** | [**List&lt;PayBatchOrderRemitDetailDTOParam&gt;**](PayBatchOrderRemitDetailDTOParam.md) |  |  [optional]
**notifyUrl** | **String** |  |  [optional]
**requestSource** | **String** |  |  [optional]
**firstProductCode** | **String** |  |  [optional]
**secondProductCode** | **String** |  |  [optional]
**thirdProductCode** | **String** |  |  [optional]
**extInfoDTO** | [**PayBatchOrderBatchRemitExtInfoDTOParam**](PayBatchOrderBatchRemitExtInfoDTOParam.md) |  |  [optional]
**skipErrorDetail** | **Boolean** |  |  [optional]



