
# PayBatchOrderBatchRemitRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回描述 |  [optional]
**batchNo** | **String** | 批次号 |  [optional]
**batchErrorDetailList** | [**List&lt;PayBatchOrderRemitDetailRespDTOResult&gt;**](PayBatchOrderRemitDetailRespDTOResult.md) | 校验不通过明细 |  [optional]
**batchAcceptDetailList** | [**List&lt;PayBatchOrderRemitDetailRespDTOResult&gt;**](PayBatchOrderRemitDetailRespDTOResult.md) | 受理明细 |  [optional]



