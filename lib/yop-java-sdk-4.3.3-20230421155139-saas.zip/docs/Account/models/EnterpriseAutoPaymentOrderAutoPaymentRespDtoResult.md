
# EnterpriseAutoPaymentOrderAutoPaymentRespDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 请求状态码 |  [optional]
**message** | **String** | 响应描述信息 |  [optional]
**orderId** | **String** | 商户请求订单号 |  [optional]
**uniqueOrderNo** | **String** | 易宝唯一订单号 |  [optional]
**orderStatus** | **String** | 订单状态 |  [optional]



