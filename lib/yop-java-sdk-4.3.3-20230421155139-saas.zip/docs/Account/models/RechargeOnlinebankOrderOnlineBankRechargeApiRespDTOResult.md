
# RechargeOnlinebankOrderOnlineBankRechargeApiRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息 |  [optional]
**orderNo** | **String** | 易宝订单号 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**merchantNo** | **String** | 充值商户编号 |  [optional]
**status** | **String** | 状态 |  [optional]
**orderAmount** | [**BigDecimal**](BigDecimal.md) | 支付金额 |  [optional]
**payUrl** | **String** | 收银台链接 |  [optional]



