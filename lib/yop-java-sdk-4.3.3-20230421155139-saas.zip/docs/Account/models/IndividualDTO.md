
# IndividualDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**merchantNo** | **String** | &lt;p&gt;商户编号&lt;/p&gt; | 
**id** | **Long** | &lt;p&gt;收款方id&lt;/p&gt; | 
**name** | **String** | &lt;pre&gt;个人姓名&lt;/pre&gt; | 
**phone** | **String** | &lt;p&gt;手机号&lt;/p&gt; | 
**certificateType** | **String** | &lt;p&gt;证件类型&lt;/p&gt; | 
**certificateNo** | **String** | &lt;p&gt;证件号&lt;/p&gt; | 



