
# AccountManageBankAccountOpenJsbcOpenAccountDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountType** | **String** |  |  [optional]
**bindCardType** | **String** |  |  [optional]
**bindCardNo** | **String** |  |  [optional]
**bindBankCode** | **String** |  |  [optional]
**bindAccountName** | **String** |  |  [optional]
**businessLicenceEffectiveDate** | **String** |  |  [optional]
**businessLicenceExpirationDate** | **String** |  |  [optional]
**legalLicenceEffectiveDate** | **String** |  |  [optional]
**legalLicenceExpirationDate** | **String** |  |  [optional]
**registerAddress** | **String** |  |  [optional]
**organizationNo** | **String** |  |  [optional]
**organizationStart** | **String** |  |  [optional]
**organizationNoEnd** | **String** |  |  [optional]
**taxNo** | **String** |  |  [optional]



