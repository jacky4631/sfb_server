
# AccountinfosQueryAccountDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountType** | **String** | 账户类型 |  [optional]
**createTime** | **String** | 开户时间 |  [optional]
**balance** | [**BigDecimal**](BigDecimal.md) | 余额 |  [optional]
**accountStatus** | **String** | 账户状态 |  [optional]



