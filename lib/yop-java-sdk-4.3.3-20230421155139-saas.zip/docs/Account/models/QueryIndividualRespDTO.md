
# QueryIndividualRespDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | &lt;p&gt;返回码,响应成功时返回UA00000&lt;/p&gt; | 
**returnMsg** | **String** | &lt;p&gt;返回信息&lt;/p&gt; |  [optional]
**resultList** | [**List&lt;IndividualDTO&gt;**](IndividualDTO.md) | &lt;p&gt;返回详情&lt;/p&gt; |  [optional]



