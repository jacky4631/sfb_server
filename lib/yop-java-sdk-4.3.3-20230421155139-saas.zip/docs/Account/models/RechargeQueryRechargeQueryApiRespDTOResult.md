
# RechargeQueryRechargeQueryApiRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息 |  [optional]
**createTime** | **String** | 下单时间 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**orderNo** | **String** | 充值订单号 |  [optional]
**status** | **String** | 订单状态 |  [optional]
**merchantNo** | **String** | 充值商户编号 |  [optional]
**orderAmount** | [**BigDecimal**](BigDecimal.md) | 支付金额 |  [optional]
**creditAmount** | [**BigDecimal**](BigDecimal.md) | 入账金额 |  [optional]
**fee** | [**BigDecimal**](BigDecimal.md) | 手续费 |  [optional]
**payType** | **String** | 支付方式 |  [optional]
**remitComment** | **String** | 汇款备注码 |  [optional]
**bankCode** | **String** | 银行编码 |  [optional]
**bankName** | **String** | 银行名称 |  [optional]
**payerAccountNo** | **String** | 付款方账号 |  [optional]
**payerAccountName** | **String** | 付款方开户名 |  [optional]
**remark** | **String** | 备注 |  [optional]
**finishTime** | **String** | 充值完成时间 |  [optional]
**failReason** | **String** | 充值失败原因 |  [optional]



