
# SupplierQueryProgressApplySupplierProgressRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 响应编码 |  [optional]
**returnMsg** | **String** | 响应描述 |  [optional]
**supplierId** | **Long** | 供应商id |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**applicationStatus** | **String** | 审批状态 |  [optional]
**applyTime** | **String** | 申请时间 |  [optional]
**finishTime** | **String** | 审批完成时间 |  [optional]



