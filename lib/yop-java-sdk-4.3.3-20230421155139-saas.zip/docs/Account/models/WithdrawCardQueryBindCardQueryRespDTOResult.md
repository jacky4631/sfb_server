
# WithdrawCardQueryBindCardQueryRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**bankCardAccountList** | [**List&lt;WithdrawCardQueryBankCardAccountResult&gt;**](WithdrawCardQueryBankCardAccountResult.md) | 提现卡列表 |  [optional]



