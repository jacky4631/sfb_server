
# SupplierApplySupplierAccountInfoParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**supplierName** | **String** |  |  [optional]
**supplierType** | **String** |  |  [optional]



