
# PayBatchOrderRemitDetailRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 错误码 |  [optional]
**returnMsg** | **String** | 描述 |  [optional]
**requestNo** | **String** | 请求号 |  [optional]
**orderNo** | **String** | 易宝流水号 |  [optional]



