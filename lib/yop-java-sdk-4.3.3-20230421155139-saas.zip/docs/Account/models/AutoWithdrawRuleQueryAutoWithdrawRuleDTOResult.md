
# AutoWithdrawRuleQueryAutoWithdrawRuleDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ruleId** | **String** | 规则id |  [optional]
**createTime** | **String** | 规则创建时间 |  [optional]
**merchantNo** | **String** | 交易主体商编 |  [optional]
**status** | **String** | 规则状态 |  [optional]
**receiveType** | **String** | 提现到账类型 |  [optional]
**bindId** | **String** | 提现卡id |  [optional]
**bankAccountNo** | **String** | 提现卡卡号 |  [optional]
**triggerTime** | **String** | 触发时间 |  [optional]
**remainAmount** | [**BigDecimal**](BigDecimal.md) | 保留金额 |  [optional]
**remark** | **String** | 银行附言 |  [optional]



