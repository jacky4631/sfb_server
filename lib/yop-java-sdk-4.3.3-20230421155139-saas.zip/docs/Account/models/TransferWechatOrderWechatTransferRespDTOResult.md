
# TransferWechatOrderWechatTransferRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息 |  [optional]
**status** | **String** | 转账状态 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**amount** | [**BigDecimal**](BigDecimal.md) | 转账金额 |  [optional]
**orderNo** | **String** | 订单号 |  [optional]



