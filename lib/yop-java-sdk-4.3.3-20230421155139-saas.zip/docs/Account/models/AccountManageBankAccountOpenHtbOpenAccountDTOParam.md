
# AccountManageBankAccountOpenHtbOpenAccountDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**businessLicenceEffectiveDate** | **String** |  |  [optional]
**businessLicenceExpirationDate** | **String** |  |  [optional]
**enterpriseEmail** | **String** |  |  [optional]
**mobileNo** | **String** |  |  [optional]
**legalLicenceEffectiveDate** | **String** |  |  [optional]
**legalLicenceExpirationDate** | **String** |  |  [optional]
**legalMobileNo** | **String** |  |  [optional]
**shareholderName** | **String** |  |  [optional]
**shareholderCertificateType** | **String** |  |  [optional]
**shareholderCertificateNo** | **String** |  |  [optional]
**shareholderEffectiveDate** | **String** |  |  [optional]
**shareholderExpirationDate** | **String** |  |  [optional]
**shareholderMobileNo** | **String** |  |  [optional]
**benefitName** | **String** |  |  [optional]
**benefitCertificateType** | **String** |  |  [optional]
**benefitCertificateNo** | **String** |  |  [optional]
**benefitEffectiveDate** | **String** |  |  [optional]
**benefitExpirationDate** | **String** |  |  [optional]
**benefitAddress** | **String** |  |  [optional]
**benefitMobileNo** | **String** |  |  [optional]
**registerProvince** | **String** |  |  [optional]
**registerCity** | **String** |  |  [optional]
**registerDistinct** | **String** |  |  [optional]
**registerAddress** | **String** |  |  [optional]



