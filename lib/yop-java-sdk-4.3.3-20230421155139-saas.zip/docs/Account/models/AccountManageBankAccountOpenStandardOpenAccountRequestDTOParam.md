
# AccountManageBankAccountOpenStandardOpenAccountRequestDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestNo** | **String** |  |  [optional]
**initiateMerchantNo** | **String** |  |  [optional]
**parentMerchantNo** | **String** |  |  [optional]
**merchantNo** | **String** |  |  [optional]
**merchantName** | **String** |  |  [optional]
**openBankCode** | **String** |  |  [optional]
**openAccountType** | **String** |  |  [optional]
**certificateType** | **String** |  |  [optional]
**certificateNo** | **String** |  |  [optional]
**notifyUrl** | **String** |  |  [optional]
**appKey** | **String** |  |  [optional]
**saleProductCode** | **String** |  |  [optional]
**xibOpenAccountDTO** | [**AccountManageBankAccountOpenXibOpenAccountDTOParam**](AccountManageBankAccountOpenXibOpenAccountDTOParam.md) |  |  [optional]
**htbOpenAccountDTO** | [**AccountManageBankAccountOpenHtbOpenAccountDTOParam**](AccountManageBankAccountOpenHtbOpenAccountDTOParam.md) |  |  [optional]
**jsbcOpenAccountDTO** | [**AccountManageBankAccountOpenJsbcOpenAccountDTOParam**](AccountManageBankAccountOpenJsbcOpenAccountDTOParam.md) |  |  [optional]
**whzbbOpenAccountDTO** | [**AccountManageBankAccountOpenWhzbbOpenAccountDTOParam**](AccountManageBankAccountOpenWhzbbOpenAccountDTOParam.md) |  |  [optional]



