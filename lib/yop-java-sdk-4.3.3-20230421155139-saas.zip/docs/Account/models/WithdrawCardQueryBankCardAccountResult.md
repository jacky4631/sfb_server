
# WithdrawCardQueryBankCardAccountResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bankCardType** | **String** | 银行卡类型 |  [optional]
**accountName** | **String** | 开户名 |  [optional]
**bankCode** | **String** | 开户行编码 |  [optional]
**accountNo** | **String** | 银行账号 |  [optional]
**bindCardId** | **String** | 银行卡标识 |  [optional]



