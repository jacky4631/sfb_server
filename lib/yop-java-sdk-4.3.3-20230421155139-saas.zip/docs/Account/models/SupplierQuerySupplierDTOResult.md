
# SupplierQuerySupplierDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**merchantNo** | **String** | 商户编号 |  [optional]
**supplierId** | **Long** | 供应商id |  [optional]
**supplierType** | **String** | 供应商类型 |  [optional]
**supplierName** | **String** | 供应商名称 |  [optional]
**supplierQualLicenceNo** | **String** | 供应商资质编码 |  [optional]
**createTime** | **String** | 供应商创建时间 |  [optional]



