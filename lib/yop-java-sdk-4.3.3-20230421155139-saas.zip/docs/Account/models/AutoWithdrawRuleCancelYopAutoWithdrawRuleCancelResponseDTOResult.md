
# AutoWithdrawRuleCancelYopAutoWithdrawRuleCancelResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 系统返回码 |  [optional]
**returnMsg** | **String** | 系统返回描述 |  [optional]



