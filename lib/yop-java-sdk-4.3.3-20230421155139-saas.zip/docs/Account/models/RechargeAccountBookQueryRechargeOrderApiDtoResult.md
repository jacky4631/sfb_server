
# RechargeAccountBookQueryRechargeOrderApiDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createTime** | **String** | 创建时间 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**orderNo** | **String** | 易宝唯一单号 |  [optional]
**status** | **String** | 订单状态 |  [optional]
**merchantNo** | **String** | 收款商户编号 |  [optional]
**orderAmount** | [**BigDecimal**](BigDecimal.md) | 订单金额 |  [optional]
**creditAmount** | [**BigDecimal**](BigDecimal.md) | 入账金额 |  [optional]
**fee** | [**BigDecimal**](BigDecimal.md) | 手续费 |  [optional]
**payType** | **String** | 支付方式 |  [optional]
**bankCode** | **String** | 银行编码 |  [optional]
**bankName** | **String** | 银行名称 |  [optional]
**payerAccountNo** | **String** | 付款方账号 |  [optional]
**payerAccountName** | **String** | 付款方账户名称 |  [optional]
**remark** | **String** | 备注 |  [optional]
**finishTime** | **String** | 完成时间 |  [optional]
**reason** | **String** | 失败原因 |  [optional]
**ypAccountBookNo** | **String** | 记账薄编号 |  [optional]



