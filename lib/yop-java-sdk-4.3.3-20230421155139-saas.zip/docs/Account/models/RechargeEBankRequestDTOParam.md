
# RechargeEBankRequestDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bankCode** | **String** |  |  [optional]
**redirectUrl** | **String** |  |  [optional]



