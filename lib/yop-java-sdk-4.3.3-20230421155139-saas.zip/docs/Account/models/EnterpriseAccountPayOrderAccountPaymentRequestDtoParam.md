
# EnterpriseAccountPayOrderAccountPaymentRequestDtoParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**appKey** | **String** |  |  [optional]
**yopMerchantNo** | **String** |  |  [optional]
**parentMerchantNo** | **String** |  |  [optional]
**merchantNo** | **String** |  |  [optional]
**payerMerchantNo** | **String** |  |  [optional]
**marketingProductCode** | **String** |  |  [optional]
**orderInfo** | [**EnterpriseAccountPayOrderOrderInfoDtoParam**](EnterpriseAccountPayOrderOrderInfoDtoParam.md) |  |  [optional]
**merchantRequestIp** | **String** |  |  [optional]



