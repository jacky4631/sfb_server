
# BankPaymentOrderBankAccountPaymentRespDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 响应编码 |  [optional]
**message** | **String** | 返回描述 |  [optional]
**uniqueOrderNo** | **String** | 易宝唯一订单号 |  [optional]
**orderId** | **String** | 商户订单号 |  [optional]
**orderStatus** | **String** | 订单状态 |  [optional]
**paymentUniqueOrderNo** | **String** | 支付订单号 |  [optional]



