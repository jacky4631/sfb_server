
# AccountBookQueryRefundQueryAccountBookRefundRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息 |  [optional]
**refundStatus** | **String** | 退款状态 |  [optional]
**refundAmount** | [**BigDecimal**](BigDecimal.md) | 退款金额 |  [optional]
**merchantRefundRequestNo** | **String** | 商户退款请求号 |  [optional]
**merchantOriginalRequestNo** | **String** | 商户原单请求号 |  [optional]
**refundOrderNo** | **String** | 易宝退款单号 |  [optional]
**bankPostscrip** | **String** | 银行附言 |  [optional]



