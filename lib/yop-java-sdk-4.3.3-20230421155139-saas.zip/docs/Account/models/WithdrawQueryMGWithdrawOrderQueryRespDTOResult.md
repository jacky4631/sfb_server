
# WithdrawQueryMGWithdrawOrderQueryRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**orderNo** | **String** | 易宝提现订单号 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**orderAmount** | [**BigDecimal**](BigDecimal.md) | 提现金额 |  [optional]
**receiveAmount** | [**BigDecimal**](BigDecimal.md) | 到账金额 |  [optional]
**debitAmount** | [**BigDecimal**](BigDecimal.md) | 扣账金额 |  [optional]
**orderTime** | **String** | 提现下单时间 |  [optional]
**finishTime** | **String** | 提现完成时间 |  [optional]
**status** | **String** | 提现订单状态 |  [optional]
**failReason** | **String** | 失败原因 |  [optional]
**feeUndertakerMerchantNo** | **String** | 手续费承担方商编 |  [optional]
**fee** | [**BigDecimal**](BigDecimal.md) | 手续费 |  [optional]
**receiveType** | **String** | 到账类型 |  [optional]
**accountName** | **String** | 开户名 |  [optional]
**accountNo** | **String** | 银行账号 |  [optional]
**bankName** | **String** | 开户行名称 |  [optional]
**isReversed** | **Boolean** | 冲退标识 |  [optional]
**reverseTime** | **String** | 冲退时间 |  [optional]
**remark** | **String** | 备注 |  [optional]



