
# EnterpriseTokenPayOrderTokenPaymentResponseDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 描述信息 |  [optional]
**token** | **String** | token |  [optional]
**orderStatus** | **String** | 订单状态 |  [optional]



