
# WithdrawOrderWithdrawOrderRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息 |  [optional]
**status** | **String** | 订单状态 |  [optional]
**orderNo** | **String** | 易宝提现订单号 |  [optional]



