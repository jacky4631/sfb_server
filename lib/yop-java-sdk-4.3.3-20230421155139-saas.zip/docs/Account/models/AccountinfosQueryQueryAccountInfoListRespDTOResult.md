
# AccountinfosQueryQueryAccountInfoListRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息 |  [optional]
**initiateMerchantNo** | **String** | 发起方商户编号 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**totalAccountBalance** | [**BigDecimal**](BigDecimal.md) | 账户总余额 |  [optional]
**accountInfoList** | [**List&lt;AccountinfosQueryAccountDTOResult&gt;**](AccountinfosQueryAccountDTOResult.md) | 账户信息列表 |  [optional]



