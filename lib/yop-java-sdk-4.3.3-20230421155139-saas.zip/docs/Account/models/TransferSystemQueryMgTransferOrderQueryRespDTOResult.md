
# TransferSystemQueryMgTransferOrderQueryRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**orderNo** | **String** | 订单号 |  [optional]
**orderAmount** | **String** | 转账金额 |  [optional]
**transferType** | **String** | 转账类型 |  [optional]
**fromMerchantNo** | **String** | 转出方商户编号 |  [optional]
**toMerchantNo** | **String** | 转入方商户编号 |  [optional]
**transferStatus** | **String** | 转账状态 |  [optional]
**usage** | **String** | 用途 |  [optional]
**fee** | **String** | 手续费 |  [optional]
**createTime** | **String** | 转账下单时间 |  [optional]
**finishTime** | **String** | 转账完成时间 |  [optional]
**debitAmount** | **String** | 扣账金额 |  [optional]
**receiveAmount** | **String** | 入账金额 |  [optional]
**feeMerchantNo** | **String** | 手续费承担方商户编号 |  [optional]



