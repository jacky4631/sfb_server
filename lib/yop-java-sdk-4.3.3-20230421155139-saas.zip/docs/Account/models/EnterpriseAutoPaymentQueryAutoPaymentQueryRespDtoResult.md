
# EnterpriseAutoPaymentQueryAutoPaymentQueryRespDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 响应编码 |  [optional]
**message** | **String** | 响应描述信息 |  [optional]
**uniqueOrderNo** | **String** | 易宝唯订单一号 |  [optional]
**merchantNo** | **String** | 收单商户编号 |  [optional]
**orderAmount** | [**BigDecimal**](BigDecimal.md) | 订单金额 |  [optional]
**orderStatus** | **String** | 订单状态 |  [optional]



