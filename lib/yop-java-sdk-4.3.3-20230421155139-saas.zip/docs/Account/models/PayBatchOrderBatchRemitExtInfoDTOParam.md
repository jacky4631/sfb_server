
# PayBatchOrderBatchRemitExtInfoDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestIP** | **String** |  |  [optional]
**terminalType** | **String** |  |  [optional]



