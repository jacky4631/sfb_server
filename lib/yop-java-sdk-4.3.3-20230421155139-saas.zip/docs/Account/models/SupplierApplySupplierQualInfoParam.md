
# SupplierApplySupplierQualInfoParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**supplierQualLicenceNo** | **String** |  |  [optional]
**supplierQualLicenceUrl** | **String** |  |  [optional]
**supplierQualFileUrl** | **String** |  |  [optional]



