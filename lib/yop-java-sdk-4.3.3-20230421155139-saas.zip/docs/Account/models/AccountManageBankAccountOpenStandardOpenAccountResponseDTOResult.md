
# AccountManageBankAccountOpenStandardOpenAccountResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回状态码 |  [optional]
**returnMsg** | **String** | 返回描述信息 |  [optional]
**requestNo** | **String** | 商户订单号 |  [optional]
**orderNo** | **String** | 易宝唯一订单号 |  [optional]
**status** | **String** | 开户状态 |  [optional]
**signUrl** | **String** | 签约地址 |  [optional]



