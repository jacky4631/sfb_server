
# EnterpriseAccountPayOrderOrderInfoDtoParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderId** | **String** |  |  [optional]
**orderAmount** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**fundProcessType** | **String** |  |  [optional]
**goodsName** | **String** |  |  [optional]
**expiredTime** | **String** |  |  [optional]
**notifyUrl** | **String** |  |  [optional]
**memo** | **String** |  |  [optional]
**csUrl** | **String** |  |  [optional]



