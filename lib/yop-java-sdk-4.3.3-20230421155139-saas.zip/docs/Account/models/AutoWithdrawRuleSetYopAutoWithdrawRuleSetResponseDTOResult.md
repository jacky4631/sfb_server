
# AutoWithdrawRuleSetYopAutoWithdrawRuleSetResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回描述 |  [optional]
**ruleId** | **String** | 规则id |  [optional]



