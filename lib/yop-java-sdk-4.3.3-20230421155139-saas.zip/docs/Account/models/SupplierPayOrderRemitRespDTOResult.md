
# SupplierPayOrderRemitRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**orderNo** | **String** | 易宝付款订单号 |  [optional]
**status** | **String** | 订单状态 |  [optional]



