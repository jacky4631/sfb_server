
# RechargeRechargeApiV2RequestDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**merchantNo** | **String** |  |  [optional]
**initiateMerchantNo** | **String** |  |  [optional]
**parentMerchantNo** | **String** |  |  [optional]
**appKey** | **String** |  |  [optional]
**requestNo** | **String** |  |  [optional]
**payType** | **String** |  |  [optional]
**amount** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**accountType** | **String** |  |  [optional]
**remark** | **String** |  |  [optional]
**notifyUrl** | **String** |  |  [optional]
**marketProductCode** | **String** |  |  [optional]
**clientIp** | **String** |  |  [optional]
**feeType** | **String** |  |  [optional]
**requestExtParams4NetPay** | [**RechargeEBankRequestDTOParam**](RechargeEBankRequestDTOParam.md) |  |  [optional]
**requestExtParams4BankPay** | [**RechargeBankPayRequestDTOParam**](RechargeBankPayRequestDTOParam.md) |  |  [optional]



