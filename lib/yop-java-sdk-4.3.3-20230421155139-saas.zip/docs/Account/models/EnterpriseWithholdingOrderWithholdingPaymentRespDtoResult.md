
# EnterpriseWithholdingOrderWithholdingPaymentRespDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 响应编码 |  [optional]
**message** | **String** | 响应描述信息 |  [optional]
**orderId** | **String** | 商户请求订单号 |  [optional]
**uniqueOrderNo** | **String** | 易宝唯一订单号 |  [optional]



