
# PayBatchOrderRemitDetailDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestNo** | **String** |  |  [optional]
**receiverAccountNo** | **String** |  |  [optional]
**receiverAccountName** | **String** |  |  [optional]
**receiverBankCode** | **String** |  |  [optional]
**orderAmount** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**comments** | **String** |  |  [optional]
**bankAccountType** | **String** |  |  [optional]
**branchBankCode** | **String** |  |  [optional]
**feeChargeSide** | **String** |  |  [optional]
**remark** | **String** |  |  [optional]



