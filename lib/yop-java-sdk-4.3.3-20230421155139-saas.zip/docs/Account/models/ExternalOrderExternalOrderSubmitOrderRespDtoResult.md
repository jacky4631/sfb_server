
# ExternalOrderExternalOrderSubmitOrderRespDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 响应码 |  [optional]
**message** | **String** | 响应描述 |  [optional]



