
# MerchantWechatauthCancelApplymentCancelRespDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 响应code |  [optional]
**returnMsg** | **String** | 响应message |  [optional]
**requestNo** | **String** | 请求号 |  [optional]



