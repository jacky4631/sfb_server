
# MerchantDisposeQueryMerchantQueryDisposeNotifyRespDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 响应编码 |  [optional]
**returnMsg** | **String** | 响应描述 |  [optional]
**applicationNo** | **String** | 申请单编号 |  [optional]
**requestNo** | **String** | 请求号 |  [optional]
**bizStatus** | **String** | 申请单状态 |  [optional]
**merchantNo** | **String** | 解冻商编 |  [optional]
**failReason** | **String** | 失败原因 |  [optional]



