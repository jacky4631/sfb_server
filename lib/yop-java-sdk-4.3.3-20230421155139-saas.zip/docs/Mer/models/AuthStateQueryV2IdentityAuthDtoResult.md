
# AuthStateQueryV2IdentityAuthDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reportMerchantNo** | **String** | 报备商户号 |  [optional]
**feeType** | **String** | 报备费率 |  [optional]
**authorizeState** | **String** | 授权状态 |  [optional]
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息 |  [optional]



