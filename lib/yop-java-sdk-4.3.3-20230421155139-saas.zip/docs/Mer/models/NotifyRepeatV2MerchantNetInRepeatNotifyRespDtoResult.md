
# NotifyRepeatV2MerchantNetInRepeatNotifyRespDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 响应编码 |  [optional]
**returnMsg** | **String** | 响应描述 |  [optional]
**requestNo** | **String** | 入网请求号 |  [optional]
**applicationNo** | **String** | 申请单编号：易宝内部商户入网申请单编号 |  [optional]



