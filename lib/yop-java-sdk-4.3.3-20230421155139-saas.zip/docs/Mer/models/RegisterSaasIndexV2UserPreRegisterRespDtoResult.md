
# RegisterSaasIndexV2UserPreRegisterRespDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**msg** | **String** | 返回信息 |  [optional]
**url** | **String** | 访问小微商户入网的注册页面地址 |  [optional]



