
# MerchantInfoModifyMerchantInfoModifyRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 响应编码 |  [optional]
**returnMsg** | **String** | 响应描述 |  [optional]
**applicationNo** | **String** | 工单号 |  [optional]
**applicationStatus** | **String** | 工单状态 |  [optional]



