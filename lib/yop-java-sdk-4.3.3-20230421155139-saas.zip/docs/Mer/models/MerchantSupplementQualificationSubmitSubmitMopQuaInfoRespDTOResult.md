
# MerchantSupplementQualificationSubmitSubmitMopQuaInfoRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 响应编码 |  [optional]
**returnMsg** | **String** | 响应描述 |  [optional]



