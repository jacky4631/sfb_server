
# ProductFeeQueryV2QueryProductFeeRespDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 响应编码 |  [optional]
**returnMsg** | **String** | 响应描述 |  [optional]
**productInfo** | **String** | 产品费率数据 |  [optional]



