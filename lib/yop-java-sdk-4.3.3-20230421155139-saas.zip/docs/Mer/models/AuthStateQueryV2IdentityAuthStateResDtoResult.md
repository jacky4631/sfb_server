
# AuthStateQueryV2IdentityAuthStateResDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 返回码 |  [optional]
**returnMsg** | **String** | 返回信息。未知状态代表商户未报备 |  [optional]
**identityAuthDtos** | [**List&lt;AuthStateQueryV2IdentityAuthDtoResult&gt;**](AuthStateQueryV2IdentityAuthDtoResult.md) | 认证信息 |  [optional]



