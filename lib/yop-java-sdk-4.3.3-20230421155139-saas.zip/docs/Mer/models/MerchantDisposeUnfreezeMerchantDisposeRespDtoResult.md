
# MerchantDisposeUnfreezeMerchantDisposeRespDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 响应编码 |  [optional]
**returnMsg** | **String** | 响应描述 |  [optional]
**requestNo** | **String** | 请求号 |  [optional]
**applicationNo** | **String** | 申请单编号 |  [optional]
**bizStatus** | **String** | 申请单状态 |  [optional]



