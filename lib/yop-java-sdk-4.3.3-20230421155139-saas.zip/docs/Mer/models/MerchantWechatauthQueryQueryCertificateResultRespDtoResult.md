
# MerchantWechatauthQueryQueryCertificateResultRespDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 响应code |  [optional]
**returnMsg** | **String** | 响应message |  [optional]
**requestNo** | **String** | 原申请请求号 |  [optional]
**applymentId** | **String** | 申请单编号 |  [optional]
**applymentState** | **String** | 申请单状态 |  [optional]
**qrcodeUrl** | **String** | 小程序码图片 |  [optional]
**rejectParam** | **String** | 驳回参数 |  [optional]
**rejectReason** | **String** | 驳回原因 |  [optional]



