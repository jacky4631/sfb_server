
# RegisterSaasWebIndexV2CreateNetInUrlRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 响应码 |  [optional]
**msg** | **String** | 响应信息 |  [optional]
**url** | **String** | 入网页面首页地址 |  [optional]



