
# MerchantSupplementQualificationQueryQueryMopQuaInfoRespDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **String** | 响应编码 |  [optional]
**returnMsg** | **String** | 响应描述 |  [optional]
**qualifications** | **String** | 后补资质类型 |  [optional]



