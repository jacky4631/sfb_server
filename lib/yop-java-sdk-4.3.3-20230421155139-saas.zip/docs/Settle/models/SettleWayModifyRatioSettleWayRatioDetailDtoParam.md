
# SettleWayModifyRatioSettleWayRatioDetailDtoParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**settleWay** | **String** |  |  [optional]
**settleRatio** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**bankCardNo** | **String** |  |  [optional]



