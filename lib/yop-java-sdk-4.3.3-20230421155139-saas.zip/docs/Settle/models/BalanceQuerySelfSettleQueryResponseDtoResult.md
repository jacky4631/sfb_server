
# BalanceQuerySelfSettleQueryResponseDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**parentMerchantNo** | **String** | 父商编 |  [optional]
**merchantNo** | **String** | 子商户编号 |  [optional]
**settlableAmount** | [**BigDecimal**](BigDecimal.md) | 可结算金额 |  [optional]
**unsettledAmount** | [**BigDecimal**](BigDecimal.md) | 未结算金额 |  [optional]



