
# SettleCardModifyMerchantSettleCardResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息描述 |  [optional]
**status** | **String** | 返回结果 |  [optional]
**parentMerchantNo** | **String** | 发起方商户编号 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]



