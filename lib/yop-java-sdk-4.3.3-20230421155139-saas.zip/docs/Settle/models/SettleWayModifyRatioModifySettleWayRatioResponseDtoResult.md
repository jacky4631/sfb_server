
# SettleWayModifyRatioModifySettleWayRatioResponseDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** | 处理结果 |  [optional]
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 修改结果描述 |  [optional]
**merchantNo** | **String** | 收款商户编号 |  [optional]
**parentMerchantNo** | **String** | 发起方商户编号 |  [optional]



