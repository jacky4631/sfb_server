
# SettleWayQueryMerchantSettleWayQueryYOPDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**settleWay** | **String** | 结算方向 |  [optional]
**settleRatio** | **Double** | 结算比例 |  [optional]
**bankCardNo** | **String** | 结算卡号 |  [optional]
**accountName** | **String** | 银行卡账户名 |  [optional]



