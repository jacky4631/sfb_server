
# SettleWayQuerySettleWayQueryYOPResponseDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** | 处理状态 |  [optional]
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回描述 |  [optional]
**merchantNo** | **String** | 收款商户编号 |  [optional]
**parentMerchantNo** | **String** | 发起方商户编号 |  [optional]
**merchantSettleWayQueryDtos** | [**List&lt;SettleWayQueryMerchantSettleWayQueryYOPDtoResult&gt;**](SettleWayQueryMerchantSettleWayQueryYOPDtoResult.md) | 结算方向列表 |  [optional]



