
# RecordsQuerySettleRecordQueryResponseDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**merchantNo** | **String** | 商户商编 |  [optional]
**settleRecordQueryDtos** | [**List&lt;RecordsQuerySettleRecordQueryDtoResult&gt;**](RecordsQuerySettleRecordQueryDtoResult.md) | 结算订单明细 |  [optional]



