
# RecordsQuerySettleRecordDetailsDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountNo** | **String** | 账号 |  [optional]
**realAmount** | [**BigDecimal**](BigDecimal.md) | 到账金额 |  [optional]
**status** | **String** | 到账状态 |  [optional]
**statusDesc** | **String** | 到账状态描述 |  [optional]
**errorCode** | **String** | 错误码 |  [optional]
**errorMessage** | **String** | 错误信息 |  [optional]
**correct** | **Boolean** | 是否冲退 |  [optional]
**channelRequestNo** | **String** | 出款流水号 |  [optional]
**accountType** | **String** | 账户类型 |  [optional]
**accountTypeDesc** | **String** | 账户类型描述 |  [optional]
**accountNameMast** | **String** | 账户名 |  [optional]



