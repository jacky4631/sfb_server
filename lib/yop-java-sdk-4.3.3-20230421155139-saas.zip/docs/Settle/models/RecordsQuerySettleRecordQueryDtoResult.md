
# RecordsQuerySettleRecordQueryDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summaryNo** | **String** | 结算订单号 |  [optional]
**settleAmount** | [**BigDecimal**](BigDecimal.md) | 应结金额 |  [optional]
**status** | **String** | 结算订单状态 |  [optional]
**statusDesc** | **String** | 结算订单状态描述 |  [optional]
**createTime** | **String** | 结算订单创建时间 |  [optional]
**settleType** | **String** | 结算产品 |  [optional]
**realAmount** | [**BigDecimal**](BigDecimal.md) | 结算到账金额 |  [optional]
**realFee** | [**BigDecimal**](BigDecimal.md) | 结算手续费 |  [optional]
**settleRecordDetailsDtos** | [**List&lt;RecordsQuerySettleRecordDetailsDtoResult&gt;**](RecordsQuerySettleRecordDetailsDtoResult.md) | 出款明细 |  [optional]



