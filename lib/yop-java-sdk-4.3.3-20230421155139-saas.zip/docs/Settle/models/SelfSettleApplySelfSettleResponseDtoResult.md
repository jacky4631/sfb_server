
# SelfSettleApplySelfSettleResponseDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**parentMerchantNo** | **String** | 发起方商户编号 |  [optional]
**merchantNo** | **String** | 收款商户编号 |  [optional]
**settleRequestNo** | **String** | 商户结算请求号 |  [optional]
**yeepayFlowNo** | **String** | 易宝结算订单号 |  [optional]



