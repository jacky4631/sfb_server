
# SettleWayModifyRatioModifySettleWayRatioRequestDtoParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**appMerchantNo** | **String** |  |  [optional]
**parentMerchantNo** | **String** |  |  [optional]
**merchantNo** | **String** |  |  [optional]
**settleWayRatioDetailDtoList** | [**List&lt;SettleWayModifyRatioSettleWayRatioDetailDtoParam&gt;**](SettleWayModifyRatioSettleWayRatioDetailDtoParam.md) |  |  [optional]



