
# QrcodeQueryQrCodeApiInfoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**qrId** | **String** | 二维码id |  [optional]
**merchantNo** | **String** | 收款商编 |  [optional]
**qrShortName** | **String** | 二维码简称 |  [optional]
**qrStatus** | **String** | 二维码状态 |  [optional]
**qrContent** | **String** | 二维码地址信息 |  [optional]
**createTime** | **String** | 创建时间 |  [optional]



