
# QrcodeQueryQueryQrCodeApiResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**retCode** | **String** | 返回码 |  [optional]
**retMsg** | **String** | 返回信息 |  [optional]
**qrCodeInfo** | [**List&lt;QrcodeQueryQrCodeApiInfoResult&gt;**](QrcodeQueryQrCodeApiInfoResult.md) | 二维码信息 |  [optional]
**requestId** | **String** | 请求号 |  [optional]
**totalCount** | **Integer** | 总条数 |  [optional]



