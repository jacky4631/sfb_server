
# FaceAuthResultQueryFaceAuthResultQueryResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requestNo** | **String** | 商户请求流水号 |  [optional]
**orderNo** | **String** | 易宝订单号 |  [optional]
**status** | **String** | 状态 |  [optional]
**extraData** | **String** | 额外数据 |  [optional]
**code** | **String** | 错误码 |  [optional]
**message** | **String** | 失败描述 |  [optional]



