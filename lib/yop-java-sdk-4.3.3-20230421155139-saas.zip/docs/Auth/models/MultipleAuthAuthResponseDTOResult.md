
# MultipleAuthAuthResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** | 认证结果 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**code** | **String** | 错误码 |  [optional]
**message** | **String** | 错误信息 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**authType** | **String** | 认证类型 |  [optional]
**ybOrderId** | **String** | 易宝流水号 |  [optional]



