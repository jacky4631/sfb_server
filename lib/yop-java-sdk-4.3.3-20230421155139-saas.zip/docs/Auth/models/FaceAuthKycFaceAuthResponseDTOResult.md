
# FaceAuthKycFaceAuthResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 错误码 |  [optional]
**message** | **String** | 错误信息 |  [optional]
**requestNo** | **String** | 商户请求号 |  [optional]
**orderNo** | **String** | 易宝订单号 |  [optional]
**status** | **String** | 状态 |  [optional]
**gatherFaceUrl** | **String** | 人脸采集地址 |  [optional]



