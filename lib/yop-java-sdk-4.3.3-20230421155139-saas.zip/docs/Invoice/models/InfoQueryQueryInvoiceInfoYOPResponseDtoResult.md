
# InfoQueryQueryInvoiceInfoYOPResponseDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**merchantNo** | **String** | 商编 |  [optional]
**mode** | **String** | 开票方式 |  [optional]
**invoiceType** | **String** | 发票类型 |  [optional]
**invoiceForm** | **String** | 发票形式 |  [optional]
**linkman** | **String** | 联系人 |  [optional]
**linkmanPhone** | **String** | 联系人电话 |  [optional]
**postalAddress** | **String** | 发票邮寄地址 |  [optional]
**postalCode** | **String** | 邮编 |  [optional]
**invoiceName** | **String** | 发票抬头 |  [optional]
**taxpayerId** | **String** | 纳税人标识 |  [optional]
**invoicePhone** | **String** | 开票联系电话 |  [optional]
**invoiceAddress** | **String** | 开票地址 |  [optional]
**bankName** | **String** | 开户银行名称 |  [optional]
**accountNo** | **String** | 账号信息 |  [optional]
**email** | **String** | 邮箱 |  [optional]
**needInvoice** | **String** | 是否需要发票 |  [optional]
**createTime** | **String** | 创建时间 |  [optional]
**lastModifyTime** | **String** | 更新时间 |  [optional]
**remark** | **String** | 备注 |  [optional]
**standardType** | **String** | 规格型号 |  [optional]
**unit** | **String** | 单位 |  [optional]
**quantity** | **Integer** | 数量 |  [optional]



