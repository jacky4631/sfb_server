
# RecordQueryQueryApplyInvoiceResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**applyInvoiceRecordList** | [**List&lt;RecordQueryApplyInvoiceYOPResponseDtoResult&gt;**](RecordQueryApplyInvoiceYOPResponseDtoResult.md) | 发票申请和开票记录List |  [optional]



