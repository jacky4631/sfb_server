
# RecordQueryIssueInvoiceDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalPriceTax** | [**BigDecimal**](BigDecimal.md) | 手续费 |  [optional]
**invoiceStatus** | **String** | 开票状态 |  [optional]
**isExpress** | **String** | 是否邮寄 |  [optional]
**pdfUrl** | **String** | 已开发票地址 |  [optional]
**pdfUrlCh** | **String** | 冲红发票地址 |  [optional]
**log** | **String** | 失败原因 |  [optional]
**expressCompany** | **String** | 快递公司 |  [optional]
**expressNumber** | **String** | 快递单号 |  [optional]



