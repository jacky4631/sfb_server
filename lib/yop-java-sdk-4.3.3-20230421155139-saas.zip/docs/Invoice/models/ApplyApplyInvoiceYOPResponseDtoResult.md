
# ApplyApplyInvoiceYOPResponseDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**merchantNo** | **String** | 商编 |  [optional]
**customerRequestNo** | **String** | 请求号 |  [optional]
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**status** | **String** | 开票状态 |  [optional]
**createDate** | **String** | 申请时间 |  [optional]
**chargingDateStart** | **String** | 收费开始时间 |  [optional]
**chargingDateEnd** | **String** | 收费结束时间 |  [optional]
**chargingMode** | **String** | 计费模式 |  [optional]
**invoiceForm** | **String** | 发票形式 |  [optional]
**amount** | [**BigDecimal**](BigDecimal.md) | 收费金额 |  [optional]
**notifyType** | **String** | 通知类型 |  [optional]
**issueInvoiceDtoList** | [**List&lt;ApplyIssueInvoiceDtoResult&gt;**](ApplyIssueInvoiceDtoResult.md) | 开票记录列表 |  [optional]



