
# InfoModifyAddOrModifyInvoiceInfoResponseDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**merchantNo** | **String** | 商编 |  [optional]
**customerRequestNo** | **String** | 请求号 |  [optional]
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**status** | **String** | 状态 |  [optional]



