
# FeeQueryGetFeeResponseDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**merchantNo** | **String** | 商编 |  [optional]
**chargingDateStart** | **String** | 收费开始日期 |  [optional]
**chargingDateEnd** | **String** | 收费结束日期 |  [optional]
**amount** | [**BigDecimal**](BigDecimal.md) | 开票金额 |  [optional]
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]



