
# PayLinkOrderAggregationPayLinkResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parentMerchantNo** | **String** | 发起方商编 |  [optional]
**merchantNo** | **String** | 收款商户商编 |  [optional]
**orderId** | **String** | 商户收款请求号 |  [optional]
**qrCodeUrl** | **String** | 订单二维码地址 |  [optional]
**uniqueOrderNo** | **String** | 易宝收款订单号 |  [optional]
**code** | **String** | 接口返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]



