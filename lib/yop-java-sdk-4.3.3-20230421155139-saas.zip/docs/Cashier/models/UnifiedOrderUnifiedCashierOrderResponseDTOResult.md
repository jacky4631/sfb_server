
# UnifiedOrderUnifiedCashierOrderResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**uniqueOrderNo** | **String** | 易宝收款订单号 |  [optional]
**cashierUrl** | **String** | 收银台链接 |  [optional]



