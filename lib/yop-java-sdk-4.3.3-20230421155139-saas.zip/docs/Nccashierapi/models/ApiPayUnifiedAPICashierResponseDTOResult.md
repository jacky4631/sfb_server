
# ApiPayUnifiedAPICashierResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 结果编码 |  [optional]
**message** | **String** | 结果信息 |  [optional]
**payTool** | **String** | 支付工具 |  [optional]
**payType** | **String** | 支付类型 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**token** | **String** | 订单token |  [optional]
**resultType** | **String** | 返回结果类型 |  [optional]
**resultData** | **String** | 返回数据 |  [optional]
**extParamMap** | **String** | 支付扩展参数 |  [optional]



