
# FacepayProxyVerifyUserInfoUserInfoResponseResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



