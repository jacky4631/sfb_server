
# FacepayProxyConfirmVerifySmscodeUserInfoResponseResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



