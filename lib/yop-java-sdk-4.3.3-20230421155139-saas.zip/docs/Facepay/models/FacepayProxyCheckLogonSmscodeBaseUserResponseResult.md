
# FacepayProxyCheckLogonSmscodeBaseUserResponseResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



