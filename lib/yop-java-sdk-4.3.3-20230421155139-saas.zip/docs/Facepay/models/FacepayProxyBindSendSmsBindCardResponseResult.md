
# FacepayProxyBindSendSmsBindCardResponseResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



