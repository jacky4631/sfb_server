
# FacepayProxyQueryOrderBeforeOrderBeforeRequestParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bizSystem** | **String** |  |  [optional]
**merchantNo** | **String** |  |  [optional]
**mtToken** | **String** |  |  [optional]
**memberNo** | **String** |  |  [optional]
**orderToken** | **String** |  |  [optional]
**merchantUserName** | **String** |  |  [optional]
**merchantUserIdNo** | **String** |  |  [optional]
**merchantUserPhone** | **String** |  |  [optional]



