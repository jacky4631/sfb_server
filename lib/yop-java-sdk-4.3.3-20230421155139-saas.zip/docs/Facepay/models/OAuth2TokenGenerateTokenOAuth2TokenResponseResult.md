
# OAuth2TokenGenerateTokenOAuth2TokenResponseResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**acctoken** | **String** | 未命名 |  [optional]
**expiresIn** | **Integer** | 未命名 |  [optional]
**expiration** | **String** | 未命名 |  [optional]
**merchantNo** | **String** | 未命名 |  [optional]
**code** | **String** | 未命名 |  [optional]



