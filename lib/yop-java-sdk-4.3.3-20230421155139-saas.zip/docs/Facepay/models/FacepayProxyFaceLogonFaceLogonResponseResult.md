
# FacepayProxyFaceLogonFaceLogonResponseResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



