
# FacepayProxyConfirmFirstCardSmscodeBaseResponseResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



