
# FacepayProxyQueryOrderBeforeOrderBeforeResponseResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



