
# FacepayProxySendLogonSmscodeBaseResponseResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



