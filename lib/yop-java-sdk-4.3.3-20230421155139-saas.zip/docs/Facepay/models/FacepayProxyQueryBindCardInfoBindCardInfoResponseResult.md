
# FacepayProxyQueryBindCardInfoBindCardInfoResponseResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



