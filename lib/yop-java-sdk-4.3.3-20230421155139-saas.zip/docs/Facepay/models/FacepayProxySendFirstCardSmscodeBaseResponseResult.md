
# FacepayProxySendFirstCardSmscodeBaseResponseResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



