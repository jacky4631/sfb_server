
# FacepayProxyOpenFaceAccountBaseUserResponseResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



