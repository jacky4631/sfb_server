
# FacepayProxyBindConfirmSmsBindCardResponseResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



