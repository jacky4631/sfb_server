
# FacepayProxySendVerifySmscodeBaseResponseResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



