
# FacepayProxyCreateBindCardBindCardResponseResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



