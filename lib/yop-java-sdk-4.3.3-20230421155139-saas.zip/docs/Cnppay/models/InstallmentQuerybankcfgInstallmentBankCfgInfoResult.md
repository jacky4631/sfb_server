
# InstallmentQuerybankcfgInstallmentBankCfgInfoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numOfInstallment** | **Integer** | 银行分期数 |  [optional]
**bankId** | **String** | 银行编码 |  [optional]
**maxQuota** | [**BigDecimal**](BigDecimal.md) | 银行最高限额 |  [optional]
**minQuota** | [**BigDecimal**](BigDecimal.md) | 银行最低限额 |  [optional]
**subsidyInterestType** | **String** | 贴息类型 |  [optional]
**payerInterestRate** | **String** | 持卡人利率 |  [optional]



