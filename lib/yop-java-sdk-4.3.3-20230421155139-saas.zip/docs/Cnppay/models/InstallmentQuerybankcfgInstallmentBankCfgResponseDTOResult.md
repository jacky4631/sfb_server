
# InstallmentQuerybankcfgInstallmentBankCfgResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**bankCfgInfo** | [**List&lt;InstallmentQuerybankcfgInstallmentBankCfgInfoResult&gt;**](InstallmentQuerybankcfgInstallmentBankCfgInfoResult.md) | 分期银行配置信息 |  [optional]



