
# InstallmentPayRequestInstallmentPayResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**merchantNo** | **String** | 收款商户商编 |  [optional]
**orderId** | **String** | 商户收款请求号 |  [optional]
**status** | **String** | 订单状态 |  [optional]
**uniqueOrderNo** | **String** | 易宝收款订单号 |  [optional]
**installmentInfo** | [**InstallmentPayRequestInstallmentApiInfoResult**](InstallmentPayRequestInstallmentApiInfoResult.md) | 分期信息 |  [optional]



