
# InstallmentPayRequestInstallmentApiInfoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**needRedirect** | **Boolean** | 是否跳转至银行分期页面 |  [optional]
**installmentRedirectUrl** | **String** | 银行分期页面跳转地址 |  [optional]



