
# RefundQueryBankPromotionInfoDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**promotionId** | **String** | 优惠券编码 |  [optional]
**promotionName** | **String** | 优惠券名称 |  [optional]
**amountRefund** | [**BigDecimal**](BigDecimal.md) | 优惠券退回金额 |  [optional]
**activityId** | **String** | 优惠券活动id |  [optional]
**channelContribute** | **String** | 渠道出资 |  [optional]
**merchantContribute** | **String** | 商户出资 |  [optional]
**otherContribute** | **String** | 其他出资 |  [optional]
**memo** | **String** | 备注信息 |  [optional]



