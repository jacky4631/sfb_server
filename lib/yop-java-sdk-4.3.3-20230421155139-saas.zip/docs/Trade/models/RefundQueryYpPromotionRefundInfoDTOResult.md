
# RefundQueryYpPromotionRefundInfoDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**marketNo** | **String** | 活动编号 |  [optional]
**ypRefundAmount** | **String** | 活动退回金额 |  [optional]
**type** | **String** | 自定义营销活动类型 |  [optional]
**couponNo** | **String** | 优惠券编号 |  [optional]



