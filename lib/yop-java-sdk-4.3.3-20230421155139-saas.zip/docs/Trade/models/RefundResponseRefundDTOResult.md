
# RefundResponseRefundDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**parentMerchantNo** | **String** | 发起方商编 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**orderId** | **String** | 商户收款请求号 |  [optional]
**refundRequestId** | **String** | 商户退款请求号 |  [optional]
**uniqueRefundNo** | **String** | 易宝退款订单号 |  [optional]
**status** | **String** | 退款订单状态 |  [optional]
**refundAmount** | **String** | 退款申请金额 |  [optional]
**refundRequestDate** | **String** | 退款受理时间 |  [optional]
**refundMerchantFee** | **String** | 退还商户手续费 |  [optional]
**refundAccountDetail** | **String** | 退款资金来源信息 |  [optional]



