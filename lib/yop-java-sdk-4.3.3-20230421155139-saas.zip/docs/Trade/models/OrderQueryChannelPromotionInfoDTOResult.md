
# OrderQueryChannelPromotionInfoDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**promotionId** | **String** | 优惠券编码 |  [optional]
**promotionName** | **String** | 优惠券名称 |  [optional]
**promotionScope** | **String** | 优惠券范围 |  [optional]
**amount** | [**BigDecimal**](BigDecimal.md) | 优惠券金额 |  [optional]
**amountRefund** | [**BigDecimal**](BigDecimal.md) | 未命名 |  [optional]
**activityId** | **String** | 优惠券活动id |  [optional]
**channelContribute** | **String** | 渠道出资 |  [optional]
**merchantContribute** | **String** | 商户出资 |  [optional]
**otherContribute** | **String** | 其他出资 |  [optional]
**memo** | **String** | 备注信息 |  [optional]



