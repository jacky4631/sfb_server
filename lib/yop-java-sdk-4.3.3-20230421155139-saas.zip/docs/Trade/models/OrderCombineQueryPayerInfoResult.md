
# OrderCombineQueryPayerInfoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bankId** | **String** | 银行编号 |  [optional]
**accountName** | **String** | 账户名称 |  [optional]
**bankCardNo** | **String** | 银行卡号 |  [optional]
**mobilePhoneNo** | **String** | 手机号 |  [optional]
**cardType** | **String** | 卡类型 |  [optional]
**userID** | **String** | 用户id |  [optional]
**unionID** | **String** | unionID |  [optional]
**buyerLogonId** | **String** | 支付宝买家登录账号 |  [optional]



