
# OrderCombineQueryYpPromotionInfoDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**marketNo** | **String** | 营销活动编号 |  [optional]
**subsidyOrderNo** | **String** | 营销订单号 |  [optional]
**type** | **String** | 营销类型 |  [optional]
**amount** | **String** | 营销金额 |  [optional]
**contributeMerchant** | **String** | 出资方商编 |  [optional]
**status** | **String** | 营销状态 |  [optional]



