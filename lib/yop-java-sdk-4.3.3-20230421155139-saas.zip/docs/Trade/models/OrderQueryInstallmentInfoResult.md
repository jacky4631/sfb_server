
# OrderQueryInstallmentInfoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instNumber** | **String** | 信用卡分期期数 |  [optional]



