
# OrderCombineQueryYopQueryCombineOrderResDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**bizSystemNo** | **String** | 未命名 |  [optional]
**parentMerchantNo** | **String** | 发起方商编 |  [optional]
**merchantNo** | **String** | 未命名 |  [optional]
**orderId** | **String** | 商户收款请求号 |  [optional]
**token** | **String** | 支付token |  [optional]
**subOrderInfoList** | [**List&lt;OrderCombineQuerySubOrderInfoDTOResult&gt;**](OrderCombineQuerySubOrderInfoDTOResult.md) | 子单信息 |  [optional]
**payerInfo** | [**OrderCombineQueryPayerInfoResult**](OrderCombineQueryPayerInfoResult.md) | 付款方信息 |  [optional]



