
# RefundSupplyYopSupplyCardInfoRefundResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**parentMerchantNo** | **String** | 发起方商编 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**orderId** | **String** | 商户收款请求号 |  [optional]
**yopMerchantNo** | **String** | yop请求商编 |  [optional]
**refundRequestId** | **String** | 商户退款请求号 |  [optional]
**uniqueRefundNo** | **String** | 商户退款请求对应在易宝的退款单号 |  [optional]
**status** | **String** | 退款状态 |  [optional]
**refundAmount** | **String** | 退款金额 |  [optional]



