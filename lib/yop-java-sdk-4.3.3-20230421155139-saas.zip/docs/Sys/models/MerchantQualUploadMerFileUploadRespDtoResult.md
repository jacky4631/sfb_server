
# MerchantQualUploadMerFileUploadRespDtoResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnMsg** | **String** | 响应信息 |  [optional]
**returnCode** | **String** | 响应编码 |  [optional]
**merQualUrl** | **String** | 商户资质存储url |  [optional]



