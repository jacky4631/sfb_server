
# SubsidyApplyYopSubsidyResDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**subsidyOrderNo** | **String** | 易宝补贴订单号 |  [optional]
**status** | **String** | 补贴状态 |  [optional]
**subsidyAmount** | **String** | 补贴金额 |  [optional]
**assumeMerchantNo** | **String** | 出资方商编 |  [optional]
**failReason** | **String** | 失败原因 |  [optional]



