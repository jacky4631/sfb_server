
# SubsidyBackQueryYopQuerySubsidyBackResDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**status** | **String** | 处理状态 |  [optional]
**subsidyBackOrderNo** | **String** | 易宝补贴退回订单号 |  [optional]
**subsidyBackAmount** | [**BigDecimal**](BigDecimal.md) | 补贴退回金额 |  [optional]
**failReason** | **String** | 失败原因 |  [optional]



