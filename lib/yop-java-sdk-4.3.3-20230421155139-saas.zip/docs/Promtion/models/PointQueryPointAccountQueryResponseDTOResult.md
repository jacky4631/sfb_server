
# PointQueryPointAccountQueryResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回描述 |  [optional]
**parentMerchantNo** | **String** | 业务发起商编 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**merchantUserNo** | **String** | 商户用户ID |  [optional]
**pointAccountStatus** | **String** | 账户状态 |  [optional]
**pointAccountNo** | **String** | 易宝积分账户编号 |  [optional]
**pointAccountType** | **String** | 账户类型 |  [optional]
**point** | [**BigDecimal**](BigDecimal.md) | 积分数 |  [optional]



