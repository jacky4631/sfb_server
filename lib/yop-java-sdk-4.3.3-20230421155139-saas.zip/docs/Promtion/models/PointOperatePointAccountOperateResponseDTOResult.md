
# PointOperatePointAccountOperateResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回描述 |  [optional]
**unionPointNo** | **String** | 易宝订单号 |  [optional]
**status** | **String** | 变更结果 |  [optional]



