
# FastbindcardRequestOpenNetsUnionAuthBindCardResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 错误描述 |  [optional]
**merchantNo** | **String** | 商编 |  [optional]
**merchantFlowId** | **String** | 商户绑卡请求号 |  [optional]
**nopOrderId** | **String** | 易宝绑卡唯一订单号 |  [optional]
**submitMethod** | **String** | 参数提交方式 |  [optional]
**submitUrl** | **String** | 鉴权请求地址 |  [optional]
**encoding** | **String** | url编码方式 |  [optional]



