
# UpopActivescanQuerypayresultOpenQueryActiveScanPayResultRequestDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**merchanNo** | **String** |  |  [optional]
**merchantFlowId** | **String** |  |  [optional]



