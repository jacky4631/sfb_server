
# BankTransferPayAPIOfflineTransferResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**msg** | **String** | 返回信息 |  [optional]
**payStatus** | **String** | 支付状态 |  [optional]
**remitRemarkCode** | **String** | 附言 |  [optional]
**receiveName** | **String** | 收款方名称 |  [optional]
**receiveAccountNo** | **String** | 收款方账号 |  [optional]
**accountName** | **String** | 收款方开户行 |  [optional]
**areaInfo** | **String** | 省市／地区 |  [optional]
**amount** | [**BigDecimal**](BigDecimal.md) | 转账金额 |  [optional]
**uniqueOrderNo** | **String** | 易宝收款订单号 |  [optional]



