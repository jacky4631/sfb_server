
# UpopPassivescanValidateOpenPassiveValidateResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 响应码 |  [optional]
**message** | **String** | 响应码描述 |  [optional]
**merchantFlowId** | **String** | 商户订单号 |  [optional]
**dealStatus** | **String** | 处理状态 |  [optional]



