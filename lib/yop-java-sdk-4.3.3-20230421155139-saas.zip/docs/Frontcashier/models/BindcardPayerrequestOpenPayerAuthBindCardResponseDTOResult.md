
# BindcardPayerrequestOpenPayerAuthBindCardResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 未命名 |  [optional]
**message** | **String** | 未命名 |  [optional]
**parentMerchantNo** | **String** | 未命名 |  [optional]
**merchantNo** | **String** | 未命名 |  [optional]
**merchantFlowId** | **String** | 未命名 |  [optional]
**nopOrderId** | **String** | 未命名 |  [optional]
**bindId** | **String** | 未命名 |  [optional]
**submitMethod** | **String** | 未命名 |  [optional]
**submitUrl** | **String** | 未命名 |  [optional]
**encoding** | **String** | 未命名 |  [optional]
**smsSender** | **String** | 未命名 |  [optional]
**smsType** | **String** | 未命名 |  [optional]



