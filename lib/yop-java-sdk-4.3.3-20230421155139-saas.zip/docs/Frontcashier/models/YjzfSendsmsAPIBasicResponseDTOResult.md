
# YjzfSendsmsAPIBasicResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**merchantNo** | **String** | 商编 |  [optional]
**token** | **String** | 订单token |  [optional]
**recordId** | **String** | 支付记录流水号 |  [optional]



