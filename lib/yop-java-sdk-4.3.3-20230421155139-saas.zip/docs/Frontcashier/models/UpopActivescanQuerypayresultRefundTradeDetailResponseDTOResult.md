
# UpopActivescanQuerypayresultRefundTradeDetailResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payOrderNo** | **String** | 付款订单号 |  [optional]
**refundAmount** | [**BigDecimal**](BigDecimal.md) | 退款金额 |  [optional]
**refundOrderNo** | **String** | 退款订单号 |  [optional]
**status** | **String** | 退款状态 |  [optional]
**createTime** | **String** | 退款时间 |  [optional]
**refundCouponInfo** | **String** | 退款营销信息 |  [optional]
**refundOrigTxnAmt** | [**BigDecimal**](BigDecimal.md) | 申请退款金额（包含营销金额） |  [optional]



