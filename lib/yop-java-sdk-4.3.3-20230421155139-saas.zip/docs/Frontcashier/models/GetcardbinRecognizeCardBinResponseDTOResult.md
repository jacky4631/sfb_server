
# GetcardbinRecognizeCardBinResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**bankCardType** | **String** | 银行卡类型 |  [optional]
**bankName** | **String** | 银行名称 |  [optional]
**bankCode** | **String** | 银行编码 |  [optional]



