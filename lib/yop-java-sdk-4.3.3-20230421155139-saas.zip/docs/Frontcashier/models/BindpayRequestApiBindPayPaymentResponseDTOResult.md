
# BindpayRequestApiBindPayPaymentResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 结果码 |  [optional]
**message** | **String** | 信息描述 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**token** | **String** | 订单token |  [optional]
**bindId** | **String** | 绑卡ID |  [optional]
**needItems** | **String** | 需补充项名称的 集合，以\&quot;,\&quot;分隔 |  [optional]
**verifyCodeType** | **String** | 验证码类型 |  [optional]
**supplyNeedItemScene** | **String** | 提交补充项场景 |  [optional]
**recordId** | **String** | 未命名 |  [optional]



