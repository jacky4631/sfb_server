
# BindcardPayerrequestOpenPayerAuthBindCardRequestDTOParam

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parentMerchantNo** | **String** |  |  [optional]
**merchantNo** | **String** |  |  [optional]
**merchantFlowId** | **String** |  |  [optional]
**bindCallBackUrl** | **String** |  |  [optional]
**userNo** | **String** |  |  [optional]
**userType** | **String** |  |  [optional]
**bankCardNo** | **String** |  |  [optional]
**userName** | **String** |  |  [optional]
**idCardNo** | **String** |  |  [optional]
**phone** | **String** |  |  [optional]
**cvv2** | **String** |  |  [optional]
**validthru** | **String** |  |  [optional]
**riskParamExt** | **String** |  |  [optional]
**orderValidate** | **Integer** |  |  [optional]
**authType** | **String** |  |  [optional]
**empower** | **Boolean** |  |  [optional]
**cardType** | **String** |  |  [optional]
**authScene** | **String** |  |  [optional]
**pageNotifyUrl** | **String** |  |  [optional]
**appKey** | **String** |  |  [optional]
**idCardType** | **String** |  |  [optional]
**sendSms** | **Boolean** |  |  [optional]



