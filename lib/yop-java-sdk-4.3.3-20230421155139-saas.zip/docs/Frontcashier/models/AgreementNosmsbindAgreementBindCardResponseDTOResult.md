
# AgreementNosmsbindAgreementBindCardResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回描述 |  [optional]
**merchantNo** | **String** | 收单商户编号 |  [optional]
**merchantFlowId** | **String** | 商户签约请求号 |  [optional]
**nopOrderId** | **String** | 易宝唯一流水号 |  [optional]
**bindId** | **String** | 绑卡Id |  [optional]



