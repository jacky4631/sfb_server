
# BindcardGetcardbinOpenQueryCardbinResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回描述 |  [optional]
**parentMerchantNo** | **String** | 交易发起方商编 |  [optional]
**merchantNo** | **String** | 收单商户商编 |  [optional]
**bankCardType** | **String** | 卡类型 |  [optional]
**bankName** | **String** | 银行名称 |  [optional]
**bankCode** | **String** | 银行编码 |  [optional]



