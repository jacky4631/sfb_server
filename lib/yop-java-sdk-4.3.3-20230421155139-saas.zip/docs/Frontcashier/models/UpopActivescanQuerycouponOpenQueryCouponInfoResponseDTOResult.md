
# UpopActivescanQuerycouponOpenQueryCouponInfoResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 错误码 |  [optional]
**message** | **String** | 错误码描述 |  [optional]
**couponInfo** | **String** | 营销信息 |  [optional]



