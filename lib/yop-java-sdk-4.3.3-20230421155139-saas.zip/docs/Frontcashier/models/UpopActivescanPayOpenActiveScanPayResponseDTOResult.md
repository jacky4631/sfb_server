
# UpopActivescanPayOpenActiveScanPayResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 错误码 |  [optional]
**message** | **String** | 错误码描述 |  [optional]
**payOrderNo** | **String** | 付款订单号 |  [optional]



