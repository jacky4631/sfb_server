
# BindcardRequestOpenAuthBindCardResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 返回信息 |  [optional]
**parentMerchantNo** | **String** | 主商户编号 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**merchantFlowId** | **String** | 绑卡请求号 |  [optional]
**nopOrderId** | **String** |    易宝绑卡流水号 |  [optional]
**bindId** | **String** | 绑卡ID |  [optional]
**signStatus** | **String** | 签约状态 |  [optional]



