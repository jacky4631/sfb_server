
# BindpayConfirmApiBindPayConfirmResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 返回码 |  [optional]
**message** | **String** | 未命名 |  [optional]
**recordId** | **String** | 未命名 |  [optional]
**token** | **String** | 订单token |  [optional]



