
# UpopPassivescanBindQrcodeOpenPassiveScanPayResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 响应码 |  [optional]
**message** | **String** | 响应码描述 |  [optional]
**payOrderNo** | **String** | 付款方订单号 |  [optional]
**qrCode** | **String** | 二维码信息 |  [optional]
**orderValidTime** | **Integer** | 有效期时间 |  [optional]
**orderDate** | **String** | 订单创建时间 |  [optional]



