
# UpopActivescanQuerypayeeorderOpenQueryPayeeOrderInfoResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 错误码 |  [optional]
**message** | **String** | 错误码描述 |  [optional]
**paySerialNo** | **String** | 付款序列号 |  [optional]
**payeeMerchantName** | **String** | 收款方商户名称 |  [optional]
**payeeComments** | **String** | 收款方附言 |  [optional]
**tradeAmount** | [**BigDecimal**](BigDecimal.md) | 交易金额 |  [optional]



