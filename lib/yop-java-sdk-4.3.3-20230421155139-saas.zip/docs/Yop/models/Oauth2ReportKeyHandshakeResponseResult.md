
# Oauth2ReportKeyHandshakeResponseResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**keyType** | **String** | 未命名 |  [optional]
**key** | **String** | 未命名 |  [optional]



