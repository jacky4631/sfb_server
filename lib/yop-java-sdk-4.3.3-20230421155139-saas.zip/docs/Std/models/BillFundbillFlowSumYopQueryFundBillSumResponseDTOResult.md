
# BillFundbillFlowSumYopQueryFundBillSumResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 响应码 |  [optional]
**message** | **String** | 响应信息 |  [optional]
**incomeCount** | **Long** | 收入总笔数 |  [optional]
**expenditureCount** | **Long** | 支出总笔数 |  [optional]
**totalCount** | **Long** | 总笔数 |  [optional]
**totalIncome** | [**BigDecimal**](BigDecimal.md) | 收入总金额 |  [optional]
**totalExpenditure** | [**BigDecimal**](BigDecimal.md) | 支付总金额 |  [optional]
**totalAccountBalance** | [**BigDecimal**](BigDecimal.md) | 账户总余额 |  [optional]
**totalFee** | [**BigDecimal**](BigDecimal.md) | 手续费总金额 |  [optional]



