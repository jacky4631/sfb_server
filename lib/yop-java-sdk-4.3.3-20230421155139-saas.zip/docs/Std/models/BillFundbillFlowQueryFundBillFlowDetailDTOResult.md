
# BillFundbillFlowQueryFundBillFlowDetailDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountTime** | **String** | 记账时间 |  [optional]
**trxTime** | **String** | 交易时间 |  [optional]
**trxFlowNo** | **String** | 易宝流水号 |  [optional]
**trxCode** | **String** | 业务类型 |  [optional]
**merchantNo** | **String** | 商户编号 |  [optional]
**merchantName** | **String** | 商户名称 |  [optional]
**orderId** | **String** | 商户订单号 |  [optional]
**fee** | [**BigDecimal**](BigDecimal.md) | 手续费 |  [optional]
**income** | [**BigDecimal**](BigDecimal.md) | 收入 |  [optional]
**expenditure** | [**BigDecimal**](BigDecimal.md) | 支出 |  [optional]
**balance** | [**BigDecimal**](BigDecimal.md) | 账户余额 |  [optional]
**remark** | **String** | 备注 |  [optional]
**accountType** | **String** | 账户类型 |  [optional]
**orgOrderId** | **String** | 原商户订单号 |  [optional]
**bankOrderId** | **String** | 银行单号 |  [optional]
**paymentNo** | **String** | 支付单号 |  [optional]
**payerAccountName** | **String** | 付款方账户名称 |  [optional]
**payerTel** | **String** | 付款方手机号 |  [optional]
**payerAccountNo** | **String** | 付款方账号 |  [optional]
**payerBankAccType** | **String** | 付款方账户类型 |  [optional]
**payerBank** | **String** | 付款方银行 |  [optional]
**goodsName** | **String** | 商品名称 |  [optional]
**payeeAccountName** | **String** | 收款方账户名称 |  [optional]
**payeeAccountNo** | **String** | 收款方账号 |  [optional]
**payeeBankAccType** | **String** | 收款方账户类型 |  [optional]
**payeeBank** | **String** | 收款方银行 |  [optional]
**tradeDesc** | **String** | 交易描述 |  [optional]



