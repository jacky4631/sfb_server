
# BillFundbillEndbalanceApplyManualGenerationEndBalanceResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 响应码 |  [optional]
**message** | **String** | 响应信息 |  [optional]
**fileId** | **String** | 文件id |  [optional]
**status** | **String** | 文件生成的状态 |  [optional]



