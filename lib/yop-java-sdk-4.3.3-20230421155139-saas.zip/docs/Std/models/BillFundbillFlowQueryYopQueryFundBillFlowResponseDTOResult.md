
# BillFundbillFlowQueryYopQueryFundBillFlowResponseDTOResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | 响应码 |  [optional]
**message** | **String** | 响应信息 |  [optional]
**totalCount** | **Long** | 总比数 |  [optional]
**data** | [**List&lt;BillFundbillFlowQueryFundBillFlowDetailDTOResult&gt;**](BillFundbillFlowQueryFundBillFlowDetailDTOResult.md) | 响应数据 |  [optional]



